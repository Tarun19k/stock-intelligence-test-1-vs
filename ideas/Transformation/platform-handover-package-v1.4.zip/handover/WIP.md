# WIP.md — Session Continuity

> Update before ending EVERY Claude Code session (CLAUDE.md ritual step 4).

## CHECKPOINT
- Phase/item: Phase 0 not started
- State: handover package received; repo not yet scaffolded
- Next step: BUILD_PLAN 0.1
- Open questions for Tarun: none
- Last green CI: n/a
