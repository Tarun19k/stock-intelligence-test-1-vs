# CLAUDE.md — Project Constitution

> **First time in this repo?** Read `START_HERE.md` first — it is the handoff/kickoff briefing. This file is the standing law you follow every session thereafter.

> Working identity: **PLATFORM** (final name pending — see docs/NAMING.md). Rename is a find-replace.
> Executor: Claude Code CLI. Admin: Tarun. Reviews happen at **phase gates only** — within a phase, proceed autonomously per docs/BUILD_PLAN.md.

## Mission
Personal investment intelligence platform: accuracy, validated data chain, user-friendliness. Personal finance first. Recommendations only — **no trade execution, ever**. Full product spec: `docs/SPEC.md` (locked v1.0). Architecture: `docs/ARCHITECTURE.md`. What to build next: `docs/BUILD_PLAN.md` — always the authority on sequence.

## Session Ritual
1. Read `WIP.md` (root). If a CHECKPOINT exists, resume it before anything else.
2. Read the current phase section of `docs/BUILD_PLAN.md`.
3. Work the next unchecked item. Plan mode for any item touching >3 files or a schema migration.
4. Before ending: update `WIP.md` with a CHECKPOINT (state, next step, open questions), commit it.

## Invariants — DO NOT UNDO
1. **Zero-hardcoding doctrine.** Every value is (a) fetched data with TTL + provenance, or (b) a row in `admin_config`. A literal constant in app code that is neither is a defect. `tools/hardcode_sweep.py` enforces; CI fails on violations.
2. **Single-adapter rule.** Exactly one module per external source family: `worker/src/engine/adapters/yahoo.py` is the only yfinance importer; same pattern for AMFI, bhavcopy, RSS, GDELT. (GSI invariant, ported.)
3. **Store-only reads.** UI and API routes read ONLY from Supabase. No request-time calls to external data APIs, anywhere, for any reason. Ingestion workers are the only external callers.
4. **Provenance stamping.** Every row written by ingestion carries `source_id`, `fetched_at`, `ingestion_run_id`. No orphan data.
5. **Rate-limit-before-call.** Adapters check rate state before calling out, never only after failure (GSI C-005 lesson — the 429 death spiral).
6. **Sanitise chokepoint.** All user-visible string interpolation into HTML/JSX from data passes through `web/lib/sanitise.ts` / `engine/core/sanitise.py`. No raw interpolation.
7. **Accuracy ledger is load-bearing.** Every forecast is persisted at creation and scored at realization. Signal classes below `docs/FORECAST_ACCURACY.md` thresholds auto-demote in the UI. Never display an unscored class as confident.
8. **Audit immutability.** `signal_audit` and `decisions` records are INSERT-only. Status changes are new rows, never UPDATEs.
9. **`core/` purity.** `worker/src/engine/core/` imports no I/O, no Supabase client, no streamlit-era patterns. Pure functions on plain data. CI AST-check enforces.
10. **Pinned-version honesty.** Library versions are pinned; upgrades are their own commits with test runs, never ride along.
11. **No smart quotes** in any source file (recurring GSI defect class). ASCII quotes only; CI sweep included in hardcode_sweep.
12. **Disclaimers are components.** The informational/educational disclaimer renders from `web/components/Disclaimer.tsx` — single source, present on every signal/recommendation surface.

## Commit & Quality Protocol
- Conventional commits; one logical change per commit; CI (pytest + Playwright + sweeps) must be green to merge to main.
- Schema changes ONLY via new files in `supabase/migrations/` — never edit an applied migration.
- Phase exit requires: all phase items checked, CI green, QA brief written (`docs/qa-briefs/phase-N.md` — screenshots + navigation steps + before/after), Tarun sign-off recorded in `docs/DECISIONS.md`.

## Decisions (ADR)
`docs/DECISIONS.md`, append-only: `ADR-NNN · date · decision · context · consequences`. Anything that contradicts this file requires an ADR and Tarun's gate approval first.

## Donor Code
GSI Dashboard is the donor (`docs/GSI_DONOR_AUDIT.md` is the port manifest). Port instructions are per-module; do not import un-audited GSI code wholesale. GSI's Streamlit-era patterns (st.cache_data, cache_buster, session_state stores, fragments) do NOT port — their replacements are named in the audit.
