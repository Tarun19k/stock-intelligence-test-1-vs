#!/usr/bin/env python3
"""Generate equivalence fixtures from GSI donor code (donor_reference/).
Run once in Phase 0.3; outputs committed to worker/tests/fixtures/.
Uses a synthetic deterministic OHLCV series + a streamlit stub so donor
modules import without the Streamlit runtime."""
import sys, json, types, hashlib
from pathlib import Path
import numpy as np, pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "donor_reference"))

# --- streamlit stub (donor utils imports it) ---
st = types.ModuleType("streamlit")
st.session_state = {}
st.cache_data = lambda *a, **k: (a[0] if a and callable(a[0]) else (lambda f: f))
for name in ("error", "warning", "info", "markdown", "write", "caption", "metric", "columns", "expander"):
    setattr(st, name, lambda *a, **k: None)
sys.modules["streamlit"] = st

import indicators  # donor

def synth_ohlcv(n=420, seed=7):
    rng = np.random.default_rng(seed)
    rets = rng.normal(0.0004, 0.015, n)
    close = 100 * np.exp(np.cumsum(rets))
    high = close * (1 + np.abs(rng.normal(0, 0.006, n)))
    low = close * (1 - np.abs(rng.normal(0, 0.006, n)))
    open_ = np.r_[close[0], close[:-1]] * (1 + rng.normal(0, 0.003, n))
    vol = rng.integers(1e5, 5e6, n).astype(float)
    idx = pd.bdate_range("2024-01-01", periods=n)
    return pd.DataFrame({"Open": open_, "High": high, "Low": low,
                         "Close": close, "Volume": vol}, index=idx)

def jround(o, nd=8):
    if isinstance(o, dict): return {k: jround(v, nd) for k, v in o.items()}
    if isinstance(o, (list, tuple)): return [jround(v, nd) for v in o]
    if isinstance(o, (np.floating, float)):
        f = float(o); return None if np.isnan(f) else round(f, nd)
    if isinstance(o, (np.integer,)): return int(o)
    if isinstance(o, (np.bool_,)): return bool(o)
    if isinstance(o, (pd.Timestamp,)): return str(o.date())
    return o

def main():
    out = ROOT / "worker" / "tests" / "fixtures"
    out.mkdir(parents=True, exist_ok=True)
    df = synth_ohlcv()
    df.to_parquet(out / "synth_ohlcv.parquet")
    ind = indicators.compute_indicators(df.copy())
    fixtures = {
        "input_sha": hashlib.sha256(pd.util.hash_pandas_object(df).values.tobytes()).hexdigest(),
        "indicators_tail": jround(ind.tail(5).to_dict(orient="list")),
        "signal_score": jround(indicators.signal_score(ind, {"returnOnEquity": 0.18, "trailingPE": 22.0})),
        "weinstein": jround(indicators.compute_weinstein_stage(ind)),
        "elder": jround(indicators.compute_elder_screens(ind)),
        "forecast_30d": jround(indicators.compute_forecast(ind, horizon_days=30)),
    }
    sig = fixtures["signal_score"]; stage = fixtures["weinstein"]; eld = fixtures["elder"]
    try:
        fixtures["unified_verdict"] = jround(indicators.compute_unified_verdict(
            indicators.signal_score(ind, {"returnOnEquity": 0.18, "trailingPE": 22.0}),
            indicators.compute_weinstein_stage(ind),
            indicators.compute_elder_screens(ind),
            indicators.compute_forecast(ind, horizon_days=30)))
    except TypeError:
        fixtures["unified_verdict"] = "SIGNATURE_MISMATCH_capture_in_phase_0_3"
    (out / "donor_indicators_fixture.json").write_text(json.dumps(fixtures, indent=1))
    print("fixtures written:", sorted(p.name for p in out.iterdir()))

if __name__ == "__main__":
    main()
