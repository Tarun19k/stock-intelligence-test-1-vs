#!/usr/bin/env python3
"""Invariant 9: worker/src/engine/core imports only stdlib + approved scientific libs."""
import ast, sys
from pathlib import Path

ALLOWED = {"numpy", "pandas", "scipy", "cvxpy", "math", "statistics", "datetime",
           "dataclasses", "typing", "enum", "functools", "itertools", "collections",
           "hashlib", "json", "re", "abc", "warnings", "engine"}
CORE = Path(__file__).resolve().parents[1] / "worker/src/engine/core"

def main():
    fails = []
    if not CORE.exists():
        print("purity: core/ not present yet"); return 0
    for p in CORE.rglob("*.py"):
        tree = ast.parse(p.read_text())
        for node in ast.walk(tree):
            mods = []
            if isinstance(node, ast.Import): mods = [a.name for a in node.names]
            elif isinstance(node, ast.ImportFrom) and node.module: mods = [node.module]
            for m in mods:
                root = m.split(".")[0]
                if root == "engine" and ".core" not in m and m != "engine":
                    fails.append(f"{p.name}: imports {m} (core may only import engine.core)")
                elif root not in ALLOWED:
                    fails.append(f"{p.name}: imports {m} (not in core allowlist)")
    print("\n".join(fails) or "purity check: clean")
    return 1 if fails else 0

if __name__ == "__main__":
    sys.exit(main())
