#!/usr/bin/env python3
"""Invariant 1 + 11 enforcement. Exit 1 on violations.
Flags: (a) numeric/string literals in worker business logic that look like
tunable config, (b) smart quotes anywhere, (c) bare external URLs outside
adapters/seed. Allowlist via inline comment: `# noqa: hardcode <reason>`."""
import re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SMART = re.compile(r"[\u2018\u2019\u201c\u201d]")
URL = re.compile(r"https?://")
NUM = re.compile(r"(?<![\w.])(\d{2,}\.?\d*)(?![\w.])")
SCAN_NUM = ["worker/src/engine/ingestion", "worker/src/engine/synthesis",
            "worker/src/engine/forecast", "worker/src/engine/advise", "worker/src/engine/jobs.py"]
URL_OK = ["worker/src/engine/adapters", "config/", "docs/", "donor_reference/", ".claude/"]
NUM_OK_TOKENS = ("test", "fixture", "migration")

def scan():
    fails = []
    for p in ROOT.rglob("*"):
        if p.is_dir() or p.suffix not in {".py", ".ts", ".tsx", ".sql", ".json", ".md"}: continue
        rel = str(p.relative_to(ROOT))
        if "node_modules" in rel or "donor_reference" in rel: 
            continue
        text = p.read_text(errors="ignore")
        for i, line in enumerate(text.splitlines(), 1):
            if "noqa: hardcode" in line: continue
            if SMART.search(line):
                fails.append(f"{rel}:{i} smart quote (Invariant 11)")
            if p.suffix in {".py", ".ts", ".tsx"} and URL.search(line) \
               and not any(rel.startswith(ok) for ok in URL_OK):
                fails.append(f"{rel}:{i} bare URL outside adapters/config (Invariant 3)")
            if p.suffix == ".py" and any(rel.startswith(s) for s in SCAN_NUM) \
               and not any(t in rel for t in NUM_OK_TOKENS):
                for m in NUM.finditer(line):
                    if line.strip().startswith(("#", '"', "'")): break
                    fails.append(f"{rel}:{i} literal {m.group(1)} - move to admin_config (Invariant 1)")
                    break
    return fails

if __name__ == "__main__":
    f = scan()
    print("\n".join(f) or "hardcode sweep: clean")
    sys.exit(1 if f else 0)
