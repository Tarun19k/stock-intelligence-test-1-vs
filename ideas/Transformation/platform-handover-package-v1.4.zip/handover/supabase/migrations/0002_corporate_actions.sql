-- 0002: corporate actions + benchmark + calendar (GAP-06, GAP-04, GAP-07 remediation)

create table corporate_actions (
  id uuid primary key default gen_random_uuid(),
  instrument_id uuid not null references instruments(id),
  kind text not null check (kind in ('split','bonus','dividend','rights','merger','symbol_change','idcw')),
  ex_date date not null,
  ratio_num numeric, ratio_den numeric,        -- split/bonus ratios
  amount numeric,                              -- dividend/idcw per unit
  details jsonb not null default '{}',
  source_id text not null references sources(id),
  ingestion_run_id uuid not null references ingestion_runs(id),
  unique (instrument_id, kind, ex_date)
);

-- adjustment factors materialized per instrument-date; raw prices stay raw (bhavcopy truth),
-- adjusted series derived: adj_close = close * cumulative factor from this table.
create table price_adjustments (
  instrument_id uuid not null references instruments(id),
  d date not null,
  cum_factor numeric not null default 1.0,
  primary key (instrument_id, d)
);

create table market_calendar (
  exchange text not null,
  d date not null,
  is_trading_day boolean not null,
  session_open timetz, session_close timetz,
  source_id text references sources(id),
  primary key (exchange, d)
);
