-- 0001_init.sql — PLATFORM core schema
-- Conventions: snake_case; uuid pks (gen_random_uuid()); timestamptz; INSERT-only audit tables.

create extension if not exists vector;

-- ============ identity ============
-- auth.users provided by Supabase Auth.
create table profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null,
  role text not null default 'investor' check (role in ('investor','admin')),
  created_at timestamptz not null default now()
);

-- ============ provenance & ingestion ============
create table sources (
  id text primary key,                      -- 'yahoo','bhavcopy_nse','amfi','rss_rbi','gdelt',...
  family text not null,                     -- 'prices','navs','fundamentals','news','filings','macro','masters'
  display_name text not null,
  base_url text,
  is_paid boolean not null default false,
  enabled boolean not null default true,
  config jsonb not null default '{}'        -- per-source knobs (feeds, endpoints, limits)
);

create table ingestion_runs (
  id uuid primary key default gen_random_uuid(),
  source_id text not null references sources(id),
  job text not null,
  started_at timestamptz not null default now(),
  finished_at timestamptz,
  status text not null default 'running' check (status in ('running','succeeded','failed','partial')),
  rows_written int not null default 0,
  error text
);

-- ============ instruments & market data ============
create table instruments (
  id uuid primary key default gen_random_uuid(),
  symbol text not null,                     -- 'RELIANCE'
  exchange text not null,                   -- 'NSE','BSE','NASDAQ','NYSE','AMFI'
  isin text,
  kind text not null check (kind in ('equity','etf','mutual_fund','index')),
  name text not null,
  sector text, industry text, currency text not null default 'INR',
  is_active boolean not null default true,  -- delisting flag via masters refresh
  meta jsonb not null default '{}',
  source_id text references sources(id),
  fetched_at timestamptz,
  unique (symbol, exchange)
);

create table prices_eod (
  instrument_id uuid not null references instruments(id),
  d date not null,
  open numeric, high numeric, low numeric, close numeric not null, volume bigint,
  source_id text not null references sources(id),
  ingestion_run_id uuid not null references ingestion_runs(id),
  fetched_at timestamptz not null default now(),
  primary key (instrument_id, d)
);

create table quotes_intraday (
  instrument_id uuid not null references instruments(id),
  ts timestamptz not null,
  price numeric not null, volume bigint,
  source_id text not null references sources(id),
  ingestion_run_id uuid not null references ingestion_runs(id),
  primary key (instrument_id, ts)
);

create table mf_navs (
  instrument_id uuid not null references instruments(id),
  d date not null,
  nav numeric not null,
  source_id text not null references sources(id),
  ingestion_run_id uuid not null references ingestion_runs(id),
  primary key (instrument_id, d)
);

create table fundamentals_snapshots (
  id uuid primary key default gen_random_uuid(),
  instrument_id uuid not null references instruments(id),
  as_of date not null,
  data jsonb not null,                      -- normalized fundamental fields
  source_id text not null references sources(id),
  ingestion_run_id uuid not null references ingestion_runs(id),
  unique (instrument_id, as_of, source_id)
);

create table macro_series (
  series_id text not null,                  -- 'IN_REPO_RATE','IN_CPI',...
  d date not null,
  value numeric not null,
  source_id text not null references sources(id),
  ingestion_run_id uuid not null references ingestion_runs(id),
  primary key (series_id, d)
);

-- ============ portfolios ============
create table portfolios (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id),
  name text not null,
  origin text not null check (origin in ('uploaded','created')),
  created_at timestamptz not null default now()
);

create table holdings (
  id uuid primary key default gen_random_uuid(),
  portfolio_id uuid not null references portfolios(id) on delete cascade,
  instrument_id uuid not null references instruments(id),
  quantity numeric not null,
  avg_cost numeric,
  as_of date not null,
  import_batch uuid,                        -- groups one statement upload
  meta jsonb not null default '{}'
);

create table watchlist_items (
  user_id uuid not null references auth.users(id),
  instrument_id uuid not null references instruments(id),
  added_at timestamptz not null default now(),
  primary key (user_id, instrument_id)
);

-- ============ events & synthesis ============
create table events (
  id uuid primary key default gen_random_uuid(),
  source_id text not null references sources(id),
  ingestion_run_id uuid not null references ingestion_runs(id),
  published_at timestamptz,
  fetched_at timestamptz not null default now(),
  title text not null, url text, body text,
  embedding vector(768),
  cluster_id uuid,                          -- dedupe cluster representative
  relevance text check (relevance in ('pending','dropped','relevant')),
  meta jsonb not null default '{}'
);
create index events_cluster_idx on events(cluster_id);

create table dependency_edges (             -- the impact graph
  id uuid primary key default gen_random_uuid(),
  from_kind text not null,                  -- 'policy_domain','commodity','sector','instrument','macro'
  from_key text not null,
  to_kind text not null,
  to_key text not null,
  relation text not null,                   -- 'supplies','regulates','competes','input_cost',...
  direction smallint not null default 0,    -- +1 benefit, -1 harm, 0 contextual
  weight numeric not null default 1.0,
  note text
);

create table synthesis_results (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null references events(id),
  model text not null,
  input_tokens int, output_tokens int, cost_usd numeric,
  affected jsonb not null,                  -- [{instrument_id, direction, magnitude, confidence, rationale}]
  materiality_passed boolean not null,
  created_at timestamptz not null default now()
);

-- ============ signals (current state) + audit (immutable) ============
create table signals (
  instrument_id uuid not null references instruments(id),
  signal_class text not null,               -- 'momentum','trend','event_impact','valuation',...
  value jsonb not null,                     -- {score, label, confidence, inputs...}
  computed_at timestamptz not null default now(),
  demoted boolean not null default false,   -- accuracy-threshold demotion flag
  primary key (instrument_id, signal_class)
);

create table signal_audit (                 -- INSERT-only (Invariant 8)
  id uuid primary key default gen_random_uuid(),
  instrument_id uuid not null references instruments(id),
  signal_class text not null,
  old_value jsonb, new_value jsonb not null,
  trigger_kind text not null check (trigger_kind in ('scheduled_compute','event_synthesis','manual','demotion')),
  trigger_ref uuid,                         -- synthesis_results.id / ingestion_runs.id
  created_at timestamptz not null default now()
);

-- ============ forecasts & accuracy ============
create table forecasts (
  id uuid primary key default gen_random_uuid(),
  instrument_id uuid not null references instruments(id),
  horizon text not null check (horizon in ('1W','1M','3M','1Y','3Y')),
  created_at timestamptz not null default now(),
  target_date date not null,
  point numeric, band_low numeric, band_high numeric, band_level numeric not null default 0.80,
  direction text check (direction in ('up','down','flat')),
  method text not null,
  inputs_hash text not null,
  scored boolean not null default false
);

create table forecast_scores (
  forecast_id uuid primary key references forecasts(id),
  realized numeric not null,
  direction_hit boolean not null,
  in_band boolean not null,
  abs_pct_error numeric not null,
  scored_at timestamptz not null default now()
);

create table accuracy_ledger (              -- rolling-window aggregates, recomputed by job
  signal_class text not null,
  horizon text not null,
  window_label text not null,               -- 'rolling_12w','rolling_26w','cohort_6m'
  as_of date not null,
  metric text not null,                     -- 'hit_rate','band_coverage','excess_return','sharpe_delta'
  value numeric not null,
  threshold numeric not null,
  passing boolean not null,
  primary key (signal_class, horizon, window_label, as_of, metric)
);

create table recommendations (
  id uuid primary key default gen_random_uuid(),
  portfolio_id uuid not null references portfolios(id),
  created_at timestamptz not null default now(),
  kind text not null check (kind in ('trim','add','exit','hedge','hold','alpha_candidate')),
  instrument_id uuid references instruments(id),
  sizing jsonb, rationale text not null,
  regime text, evidence jsonb not null default '[]',
  efficacy jsonb                            -- filled by tracking job (post-3M sharpe vs counterfactual)
);

-- ============ admin config (Invariant 1) ============
create table admin_config (
  key text primary key,                     -- 'frequencies.eod','llm.daily_budget_usd','slice.instrument',...
  value jsonb not null,
  description text not null,
  updated_by uuid references auth.users(id),
  updated_at timestamptz not null default now()
);

create table decisions (                    -- ADR mirror, INSERT-only
  id serial primary key,
  adr text not null, decided_on date not null, decision text not null,
  context text, consequences text
);

-- ============ RLS ============
alter table profiles enable row level security;
alter table portfolios enable row level security;
alter table holdings enable row level security;
alter table watchlist_items enable row level security;
alter table recommendations enable row level security;

create policy "own profile" on profiles for select using (auth.uid() = user_id);
create policy "own portfolios" on portfolios for all using (auth.uid() = user_id);
create policy "own holdings" on holdings for all
  using (exists (select 1 from portfolios p where p.id = portfolio_id and p.user_id = auth.uid()));
create policy "own watchlist" on watchlist_items for all using (auth.uid() = user_id);
create policy "own recommendations" on recommendations for select
  using (exists (select 1 from portfolios p where p.id = portfolio_id and p.user_id = auth.uid()));

-- market-data tables: readable by all authenticated users (no RLS needed beyond default grants);
-- writes happen only via worker service role. admin_config writable via service role / admin role checks in API.
