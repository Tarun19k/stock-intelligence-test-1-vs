Update WIP.md with current CHECKPOINT (phase/item, state, next step, open questions, last green CI), then commit it with message "chore: checkpoint".
