---
paths: ["worker/src/engine/core/**"]
---
This directory is PURE (CLAUDE.md Invariant 9): stdlib + numpy/pandas/scipy/cvxpy only. No I/O, no supabase, no httpx/requests, no env reads. If a function needs data, it takes it as a parameter. tools/purity_check.py enforces in CI.
