---
paths: ["web/**"]
---
Web reads ONLY from Supabase under RLS (Invariant 3). No external fetches anywhere — Playwright network assertion will fail the build. All data interpolation through lib/sanitise.ts (Invariant 6). Every signal/recommendation surface includes <Disclaimer/> (Invariant 12). Show freshness stamps from fetched_at.
