---
paths: ["worker/src/engine/**"]
---
Only engine/store repositories write to Supabase (Invariant 4). Every write carries ingestion_run_id or an audit trigger ref. Adapters never import the store; jobs wire adapters to repos. Rate-limit check BEFORE any external call (Invariant 5). No literal constants — admin_config or fetched data only (Invariant 1).
