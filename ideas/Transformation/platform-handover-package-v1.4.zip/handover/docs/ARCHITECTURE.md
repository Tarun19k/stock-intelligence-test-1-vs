# ARCHITECTURE.md

## System Overview

```
                        ┌──────────────────────────────────────────────┐
 External sources       │  WORKER (Python · Railway/Fly, always-on)    │
 yfinance · bhavcopy ──►│  scheduler → ingestion jobs → validation gate│
 AMFI · RSS · GDELT     │  synthesis pipeline (LLM) · forecast batch   │
 filings · macro        │  scoring jobs · rebalance/alpha engine       │
                        └──────────────┬───────────────────────────────┘
                                       │ writes (service role)
                                       ▼
                        ┌──────────────────────────────────────────────┐
                        │  SUPABASE                                    │
                        │  Postgres (all state) · Auth · Storage       │
                        │  RLS per-user isolation · pg_cron triggers   │
                        └──────────────┬───────────────────────────────┘
                                       │ reads (RLS, anon/user JWT)
                                       ▼
                        ┌──────────────────────────────────────────────┐
                        │  WEB (Next.js/TS · Vercel)                   │
                        │  portfolio · signals · forecasts · events    │
                        │  accuracy ledger · admin config UI           │
                        └──────────────────────────────────────────────┘
```

Data flows one direction: **sources → worker → store → UI**. The UI never calls outward (Invariant 3). The worker never renders.

## Monorepo Layout (ADR-001: monorepo)

```
/
├── CLAUDE.md  WIP.md
├── docs/                     # this package
├── supabase/
│   ├── migrations/           # numbered SQL, append-only
│   └── seed/                 # sources.seed.json loader
├── worker/
│   ├── pyproject.toml        # Python 3.12+ (NOT 3.14 — library ecosystem maturity; ADR-002)
│   └── src/engine/
│       ├── core/             # PURE: indicators, portfolio math, forecast_engine,
│       │                     #   calc, sanitise, regime  (GSI ports live here)
│       ├── adapters/         # yahoo, bhavcopy, amfi, rss, gdelt, filings (one per source family)
│       ├── ingestion/        # jobs, validation gate, provenance writer, universe refresh
│       ├── synthesis/        # dedupe, relevance filter, llm client, materiality gate
│       ├── forecast/         # horizon runners, persistence, scoring
│       ├── advise/           # rebalance + alpha engines (cvxpy)
│       ├── store/            # supabase client, repositories (only module that writes DB)
│       └── jobs.py           # scheduler entrypoints
│   └── tests/                # pytest: unit (core), integration (against local supabase)
├── web/
│   ├── app/                  # Next.js App Router pages
│   ├── components/           # Disclaimer, SignalCard, ConfidenceBadge, charts...
│   ├── lib/                  # supabase client, sanitise.ts, formatters
│   └── e2e/                  # Playwright
├── config/                   # seed files only — runtime config lives in admin_config table
├── tools/                    # hardcode_sweep.py, purity_check.py
└── .claude/                  # rules, commands, settings
```

## Layering Rules (CI-enforced)
1. `engine/core` imports nothing outside stdlib + numpy/pandas/scipy/cvxpy. No I/O.
2. `engine/adapters/*` are the only external-API callers; each checks `rate_limit` state pre-call.
3. `engine/store` is the only Supabase writer in the worker. Repositories stamp provenance.
4. `web` reads via supabase-js under RLS; the few Next API routes are thin reads/derivations — no external fetches.
5. Synthesis may call the LLM API only through `synthesis/llm.py` (budget + logging chokepoint).

## Key Pipelines

**Ingestion (per data class, scheduled — frequencies in admin_config, defaults in docs/DATA_SOURCES.md):**
`scheduler → adapter.fetch → validation gate (schema, freshness, sanity bounds) → repository.write (+provenance, +ingestion_run) → on failure: ingestion_run marked failed, prior data stands with visible staleness`

**Synthesis (docs/SYNTHESIS_PIPELINE.md):**
`new events → embed+dedupe cluster → relevance filter vs dependency graph (cheap) → LLM synthesis (survivors only) → materiality gate → signal update + signal_audit row`

**Forecast (docs/FORECAST_ACCURACY.md):**
`nightly: per instrument×horizon → forecast row persisted with inputs hash → scoring job on realization → accuracy ledger → demotion flags`

**Portfolio analysis:**
`upload (CSV/CAS) → parser → holdings rows → enrichment join (prices, fundamentals, signals) → advise engine on demand → recommendations with rationale + audit`

## State & Auth
Supabase Auth (email magic-link for family/friends scale). Every user-owned table carries `user_id` with RLS `auth.uid() = user_id`. Market data tables are read-all. `admin_config` writable only by `role = admin` (Tarun). Multi-user is structural from day one (Spec F8); exposure beyond Tarun is a Phase 7 gate.

## Environments
local (supabase CLI) → staging (Supabase project + Vercel preview + worker dev service) → prod. Secrets: Vercel env vars, Railway/Fly secrets, never in repo. See docs/ENV_SETUP.md.
