# DECISIONS.md — ADR Log (append-only)

| ADR | Date | Decision | Context | Consequences |
|---|---|---|---|---|
| ADR-001 | 2026-06-11 | Monorepo (worker + web + supabase + docs) | Single Claude Code workspace holds whole truth; phase-gate review model | One CI; shared docs; coordinated migrations |
| ADR-002 | 2026-06-11 | Worker on Python 3.12, not 3.14 | Library wheel maturity (cvxpy, statsforecast, pandas ecosystem) | Revisit at Phase 7 |
| ADR-003 | 2026-06-11 | Lean governance: CLAUDE.md invariants + this ADR log + WIP checkpoints + gate QA briefs | GSI suite right-sized; grep-regression retired in favor of pytest+Playwright+sweeps | Less ceremony; behavior-asserting tests are the baseline |
| ADR-004 | 2026-06-11 | Vertical-slice-first build (Phase 0 scaffold+port, Phase 1 one-ticker pipe) | Proves every architectural decision before building wide | Tier-2 docs broadened during Phases 2–4 |
| ADR-005 | 2026-06-11 | Anthropic API for synthesis v1; provider abstraction deferred | Q6 answer "A for now" | synthesis/llm.py is the swap point if revisited |
| ADR-006 | 2026-06-11 | APScheduler in-worker is the single scheduler; pg_cron unused for jobs | pg_cron cannot run Python; one scheduling truth | All cadence keys in admin_config |
| ADR-007 | 2026-06-11 | GSI frozen at v5.41 (deployed app untouched) until Phase 5 parity, then retired; GSI restructure plan SUPERSEDED by this platform | Q5-A answer; donor value already extracted to GSI_DONOR_AUDIT | No GSI sprints; Tarun marks GSI repo README |
| ADR-008 | 2026-06-11 | Embeddings: sentence-transformers/all-mpnet-base-v2, local in worker | 768-dim matches schema; zero API cost | Worker image +~500MB; revisit if RAM-constrained |
| ADR-009 | 2026-06-11 | Prices stored RAW (bhavcopy truth); adjusted series derived via price_adjustments factors | Auditability + official-source fidelity (GAP-06) | All return math reads adjusted; views encapsulate |
