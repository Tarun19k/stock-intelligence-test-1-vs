# API_CONTRACTS.md — Boundaries

## The Three Boundaries

**1. Worker → Supabase (write path).** Only `engine/store` repositories write. Service-role key lives only in worker secrets. Repository contract: every write method takes an `ingestion_run` context (or audit trigger ref) — there is no bare `insert()` exposed. Repos: `PricesRepo, NavsRepo, InstrumentsRepo, EventsRepo, SignalsRepo (upsert+audit atomically), ForecastsRepo, ConfigRepo, RunsRepo, RecommendationsRepo`.

**2. Web → Supabase (read path).** supabase-js with the user's JWT under RLS. The web app holds NO service key and makes NO external API calls (Invariant 3 — enforced by a Playwright network assertion that fails E2E on any non-Supabase/non-self origin request). Reads are direct table/view selects; prefer Postgres views for anything join-heavy:
- `v_portfolio_positions` (holdings × latest price/NAV × signals × P&L)
- `v_instrument_detail` (instrument × latest signals × latest forecasts × freshness)
- `v_event_trace` (event → synthesis → signal_audit join for the "why did this change" view)
- `v_accuracy_dashboard` (ledger pivot)
Views ship as migrations from Phase 1 onward as pages need them.

**3. Web Next API routes (thin, few).** Only where a server-side secret or mutation-with-validation is required:
- `POST /api/portfolio/upload` — CSV/Excel/CAS file → parse → staged rows → mapping response. (Parsing in TS for CSV; CAS PDF parsing delegated to a worker endpoint, below.)
- `POST /api/admin/config` — validated admin_config writes (admin role check).
- `POST /api/admin/edges/approve` — dependency-graph proposal approval.
Everything else is direct supabase-js reads. No route proxies market data, ever.

**4. Web → Worker (rare, internal).** One authenticated internal endpoint on the worker: `POST /internal/parse-cas` (PDF in, staged holdings out) and `POST /internal/advise` (on-demand rebalance run for a portfolio_id; result lands in recommendations table; web polls the table). Shared-secret header; not exposed publicly beyond the two apps.

## Conventions
- All timestamps UTC in store; IST rendering is a web concern.
- Money/quantities as numeric (never float columns); web formats per instrument currency.
- Every read surface displays `fetched_at`-derived freshness ("as of 19:42 IST"). Staleness is information, not shame.
- Errors: worker jobs never throw past the run boundary — runs end `failed/partial` with error text; the admin page lists red runs. Web reads degrade to empty-state components, never white-screen.

## Versioning
Schema evolves by migration only. A view change that breaks a page ships in the same commit as the page fix. The seed file is idempotent (upsert by key) so re-running setup is safe.
