# QA_STANDARDS.md

## Test Pyramid
1. **pytest unit** (`worker/tests/unit/`) — pure core. Donor-equivalence tests assert ported functions reproduce `worker/tests/fixtures/donor_indicators_fixture.json` on `synth_ohlcv.parquet` (tolerance 1e-6; regenerate only via `tools/gen_donor_fixtures.py` + ADR).
2. **pytest integration** (`worker/tests/integration/`) — jobs against supabase-local (CI service container). Adapters tested on **recorded responses** (vcr-style fixtures); CI never calls live external APIs.
3. **Playwright E2E** (`web/e2e/`) — the behavioral regression baseline (successor to GSI's grep suite, per ADR-003). Asserts what users see, not what source files contain.
4. **Sweeps** — `tools/hardcode_sweep.py` (Invariants 1, 3, 11) + `tools/purity_check.py` (Invariant 9). CI-blocking.

## The Network Assertion (Invariant 3, mechanical form)
Every Playwright spec runs under a global route guard:
```ts
// e2e/fixtures.ts
page.route('**/*', (route) => {
  const url = new URL(route.request().url());
  const allowed = [process.env.SUPABASE_HOST!, 'localhost'];
  if (!allowed.some(h => url.host.includes(h))) {
    violations.push(url.href); route.abort();
  } else route.continue();
});
// afterEach: expect(violations).toEqual([])
```
Any page making a non-Supabase/non-self request fails E2E. This is the platform's strongest structural guarantee, tested on every PR.

## Required E2E Coverage per Phase Gate
G1: instrument page renders ingested signal + freshness stamp; network guard clean. G2: portfolio upload → mapping → positions render; P&L spot values asserted from seeded fixtures. G3: forecast bands render; demoted class shows "Informational" treatment; accuracy page populated. G4: event trace view shows event → rationale → signal delta (seeded synthesis fixture). G5: recommendation card shows kind/sizing/rationale/Disclaimer. G6: full suite is the accepted regression baseline; axe-core accessibility pass added.

## QA Brief Format (every gate; GSI Rule 15 lineage)
`docs/qa-briefs/phase-N.md`: (1) what changed, (2) **navigation steps** a human can follow click-by-click, (3) **before/after screenshots** (Playwright `--update-snapshots` artifacts acceptable), (4) CI run link + test counts, (5) known gaps carried forward. A gate without a brief does not close.

## Conventions
- Tests assert **behavior or data**, never source text (the stale-grep lesson).
- Every bug fixed gets a test that fails without the fix, committed together.
- Flaky test = quarantined same day with an issue; never retried-into-green silently.
- Seeded randomness everywhere (donor pattern: rng seed=42); no time-of-day dependent assertions — clock injected.
