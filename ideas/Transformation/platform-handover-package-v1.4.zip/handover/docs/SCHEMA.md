# SCHEMA.md — Design Notes for 0001_init.sql

Read alongside the migration. These are the decisions, not the DDL.

**Provenance is structural (Invariant 4).** Every market-data row carries `source_id + ingestion_run_id + fetched_at`. A datum's full lineage is reconstructable: row → ingestion_run → source. The validation gate writes rows only inside a run; orphan writes are impossible by convention and checked by sweep.

**Current state vs immutable history.** `signals` is a small current-state table (one row per instrument×class, UPDATEd in place); `signal_audit` is the INSERT-only history of every change with its trigger. Same pattern: `forecasts` (immutable at creation) + `forecast_scores` (one-time scoring) + `accuracy_ledger` (recomputed aggregates). Never UPDATE an applied forecast.

**The dependency graph is data.** `dependency_edges` holds typed, weighted edges between policy domains, commodities, sectors, and instruments. The synthesis relevance filter walks this graph; admins extend it through the UI. Seeding strategy: Phase 4.4 ships a starter graph for held-portfolio sectors; the LLM proposes new edges which land as `pending` for admin approval (edge proposals are cheap; approvals are human).

**admin_config is the single knob store (Invariant 1).** Frequencies, budgets, thresholds, the vertical-slice instrument, feature gates — all rows here. The worker reads config at job start; the web admin page edits it. Anything you're tempted to hardcode becomes a key here with a description.

**RLS posture.** User-owned tables (portfolios, holdings, watchlists, recommendations, profiles) are RLS-isolated by `user_id`. Market data is shared-read. The worker uses the service role and bypasses RLS — which is why `engine/store` is the only worker module allowed to hold that client (Architecture rule 3).

**Embeddings.** `events.embedding vector(768)` with pgvector for dedupe/clustering. Model choice is admin_config (`synthesis.embedding_model`); 768 dims fits the common small-embedding tier — revisit via migration if the chosen model differs.

**Intraday retention.** `quotes_intraday` is hot-only; a nightly job prunes beyond N days (admin_config `retention.intraday_days`, default 7). EOD and NAVs are permanent.

**What is deliberately absent in 0001:** bonds/gold/FD instrument kinds (future-state — add via `kind` enum migration), execution/order tables (never, per Spec Q12), multi-currency FX tables (Phase 2+ if US layer demands), notification tables (post-G7).
