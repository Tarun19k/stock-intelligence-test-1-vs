# FORECAST_ACCURACY.md — Methodology, Persistence, Scoring, Demotion

## Horizons & Methods

| Horizon | Method (v1) | Output |
|---|---|---|
| 1W, 1M | Bootstrap path simulation (ported GSI engine — block bootstrap on returns, regime-conditioned) | point + 80% band + direction |
| 3M | Bootstrap + statistical ensemble (statsforecast: AutoETS/Theta) blended by inverse recent error | point + band + direction |
| 1Y | Ensemble + fundamentals drift term (earnings trajectory from fundamentals_snapshots) | band + direction (point de-emphasized in UI) |
| 3Y | **Scenario ranges, not point forecasts**: bull/base/bear paths from regime-conditioned return distributions + valuation reversion assumption, all assumptions displayed | three labeled scenarios |

Regime detection (engine/core/regime.py): trailing `regime.lookback_days` classification (bull/bear/sideways/high-vol) from index trend + realized vol; conditions which historical blocks the bootstrap samples. This is how "credible in both regimes" is implemented rather than asserted.

Library candidates (final pick is Phase 3.1's first task, recorded as ADR): statsforecast (fast, classical, no GPU), sktime (if pipeline composition wins), NO deep-learning models in v1 (data volume doesn't justify; opacity hurts the rationale requirement).

## Persistence Contract (Invariant 7)
At creation, every forecast writes a `forecasts` row: horizon, target_date, point/band, direction, method, **inputs_hash** (sha256 of the input window + config — makes any forecast reproducible and tamper-evident). Rows are immutable. Nightly batch covers held + watchlist instruments across all horizons.

## Scoring
A daily job finds unscored forecasts with `target_date <= today`, fetches realized close from prices_eod, writes `forecast_scores`: direction_hit, in_band, abs_pct_error. 3Y scenarios score on band membership of the realized path at checkpoints (1Y, 2Y, 3Y).

## Thresholds & Demotion (gating, Spec §2)

| Metric | Gate | Window | admin_config key |
|---|---|---|---|
| Direction hit-rate 1W/1M | ≥ 0.60 | rolling 12w | thresholds.hit_rate_short |
| Direction hit-rate 3M/1Y | ≥ 0.65 | rolling 26w | thresholds.hit_rate_medium |
| 80% band coverage | 0.75–0.85 | rolling 12w | thresholds.band_coverage_* |
| Alpha cohort excess vs NIFTY50 TRI | ≥ +2% ann. | 6m cohorts | thresholds.alpha_excess_annualized |
| Alpha hit-rate | ≥ 0.55 | 6m cohorts | (seed in Phase 5) |
| Rebalance efficacy | post-rec 3M Sharpe ≥ counterfactual | per rec, qtrly agg | (seed in Phase 5) |

A weekly job recomputes `accuracy_ledger`; any failing (signal_class, horizon) sets `signals.demoted = true` for that class. **UI contract:** demoted classes render with an explicit "Informational — below accuracy threshold" treatment (muted style + label via ConfidenceBadge component); they are never hidden (hiding would break the validation-chain transparency principle) and never shown as confident.

## Backfill (Phase 3.6 — critical for credibility)
Before any live judgment, run the engine over the trailing 12 months as-if-live (walk-forward, no lookahead: each historical forecast uses only data available at its creation date) to seed the ledger. Go-live UI shows real measured accuracy from day one instead of "no data yet". Backfill rows are flagged `method = '*_backfill'` so live and backfill populations are separable.

## Accuracy Page (user-visible)
The ledger is a first-class page: per class×horizon — current hit-rate vs gate, band calibration chart, trend over time, demotion status. The chain of validation, made visible. This page is also the admin's early-warning system for model drift.
