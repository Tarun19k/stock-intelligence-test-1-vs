# GSI_DONOR_AUDIT.md — Port Manifest (E1)

Donor: `stock-intelligence-test-1-vs` @ v5.41 (commit ce3bef3, 2026-05-25). Function-level inventory verified against source. Rule: port by **copying and adapting into the new layout with tests** — never `pip install` the donor or import it wholesale. Streamlit-era patterns do not cross the boundary.

## PORT — into `worker/src/engine/core/` (Phase 0.3)

**From `indicators.py` (670 lines, already pure):** `compute_indicators`, `signal_score`, `compute_weinstein_stage`, `compute_elder_screens`, `compute_forecast` + `_holt_winters_damped`, `compute_unified_verdict`, `_calc_roe`. → `core/indicators.py`. Adaptation: none functional; replace `from utils import safe_float` with `core.calc`. Indicator weights become admin_config keys (they are currently in-code constants — zero-hardcoding doctrine applies; this also unblocks the donor's OPEN-004 weights audit as a platform task).

**From `portfolio.py` (462 lines, pure, cvxpy):** `check_data_quality`, `compute_log_returns`, `winsorize_returns`, `bootstrap_scenarios`, `compute_efficient_frontier`, `optimise_mean_cvar`, `compute_stability_score`, `detect_stress_regime`, `check_regime_conflicts`. → `core/portfolio.py` (advise engine substrate) and `detect_stress_regime` seeds `core/regime.py`.

**From `forecast.py` (456 lines — SPLIT, the donor's known Streamlit leak):**
- PORT the math: `store_forecast`'s computation half, `resolve_forecasts`' scoring logic, `compute_correction_factor`, `get_accuracy_summary`/`get_weekly_accuracy_report` aggregation logic → `core/forecast_engine.py` + `forecast/scoring.py`, re-targeted from session-state dicts to the forecasts/forecast_scores tables.
- RETIRE: `load_forecast_history`/`save_forecast_history` (JSON file + session_state — replaced by Postgres), `render_forecast_accuracy` (Streamlit rendering — replaced by web Accuracy page).

**From `utils.py`:** `calc_5d_change`, `safe_float`, `safe_run` → `core/calc.py`; `sanitise`, `sanitise_bold`, `safe_ticker_key`, `safe_url` → `core/sanitise.py` (+ mirror in `web/lib/sanitise.ts`). RETIRE: `init_session_state`, error-log session writes.

## PORT WITH ADAPTATION — into `engine/adapters/` + `engine/ingestion/` (Phase 1)

**From `market_data.py` (676 lines):**
- `_yf_download`, `_yf_batch_download`, `_parse_batch_raw`, `_normalize_df`, `_safe_close` → `adapters/yahoo.py`. The embedded hard-won fixes travel: C-003 MultiIndex flattening, C-004 ROE None-guard, C-006 warning suppression.
- `_is_rate_limited`, `_set_rate_limited`, `_clear_rate_limit_state`, `_global_throttle` → `engine/rate_limit.py`, pre-call check preserved (C-005 — Invariant 5).
- `_is_allowed_rss` allowlist pattern + `get_news` parsing → `adapters/rss.py`.
- RETIRE: all `@st.cache_data` wrappers and every `cache_buster` parameter (the local store IS the cache now), `get_live_price`/`get_price_data`/`get_ticker_info`/`get_top_movers`/`get_batch_data`/`get_ticker_bar_data_fresh` public facade (their roles become ingestion jobs + store reads), `is_ticker_cache_warm`, `get_health_stats`/`get_rate_limit_state` (superseded by ingestion_runs + admin page).

**From `data_manager.py` (702 lines, M2, never reached production):**
- PORT concepts, not code: `DataContract` validation patterns → the ingestion validation gate; `CircuitBreaker` → wrap adapters in the worker; `Priority`/`DataType` enums → job scheduling vocabulary.
- RETIRE: `CacheManager` (Postgres replaces L1/L2/L3), `DataManager` orchestration + bypass machinery (the scheduler+store architecture makes the whole M1–M4 program unnecessary — its destination is this platform's starting point).

## RETIRE OUTRIGHT (no successor needed)
`app.py` routing & 4-state view machine · `pages/` (all 6 views, ~4,500 lines — UI is rebuilt in Next.js with new design) · `styles.py` CSS + MPA-hiding hack · Streamlit fragments · `regression.py` (1,237 grep checks → pytest + Playwright + the two sweep tools) · `config.py` (tickers.json → dynamic universe; constants → admin_config; HELP_TEXT/GLOBAL_TOPICS copy → web content) · `generate_context.py`/sync scripts · `GSI_session.json` state files.

## LEARNINGS THAT BECAME LAW (already encoded in CLAUDE.md)
Single-adapter rule (Inv. 2) · rate-limit-before-call / 429 death spiral (Inv. 5) · sanitise chokepoint (Inv. 6) · audit immutability (Inv. 8) · smart-quote ban (Inv. 11) · QA briefs with screenshots + nav steps (gate protocol) · disclaimers as components (Inv. 12) · stale-check risk → tests assert behavior, not source text.

## Port Order & Test Expectations (Phase 0.3 execution detail)
1. `core/calc.py` + `core/sanitise.py` (no deps) — golden-value tests.
2. `core/indicators.py` — fixture: a saved real OHLCV parquet; assert signal outputs match donor outputs byte-for-byte on the fixture (regression-equivalence test, run once against donor values committed as fixtures).
3. `core/portfolio.py` — same fixture approach; cvxpy solution tolerance 1e-6.
4. `core/forecast_engine.py` — deterministic with seeded RNG; equivalence on seeded runs.
5. Adapters in Phase 1 with recorded-response tests (no live calls in CI).
