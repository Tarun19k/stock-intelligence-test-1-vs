# NAMING.md — Candidates & Compliance Notes

Working identity until decided: PLATFORM. Rename = repo-wide find-replace + repo rename.

| Candidate | Angle | Notes |
|---|---|---|
| **Artha** (variants: ArthaLens, ArthaMind) | Sanskrit: wealth + purpose | First pick. 2 syllables, category-true, deep recall in IN market |
| **Sankhya** | number + analytical philosophy school | Signals quantitative rigor with heritage. Close second |
| Nivra | coined from nivesh | Short, modern, app-store friendly |
| Drishti | vision/insight | Literally what the synthesis layer does |
| Kuberion | Kubera + -ion | Memorable, tech-brand energy |
| AlphaVeda | alpha + knowledge | Speaks to investment-literate buyers |
| Meru | the axis mountain | Stability; strong 4-letter mark |
| Pravaha | flow | Echoes validated data chain |

Compliance guardrails (applies to final pick + all UI copy):
- No "Advisor/Advisory", "Wealth Management", "Assured", "Guaranteed", "SEBI" in name or tagline — avoids implying IA/RA registration or assured returns.
- Before committing: MCA name search, trademark classes 36/42, domain + handle check.
- Decision recorded as an ADR; rename executed before Phase 6 (design system bakes the name in).
