# COMPLIANCE_NOTES.md — Source Terms, Posture, Cost Optimization

## Data-Source Terms (practical pass, personal-use posture)

| Source | Status | Position |
|---|---|---|
| AMFI NAVAll, RBI/SEBI/PIB feeds, FRED, data.gov.in, GDELT | Official/open | Clean for any use |
| NSE/BSE bhavcopy + masters + holiday calendar | Official published files | Clean for personal use; respect request etiquette (UA header, off-peak, no hammering — the scheduler already guarantees this) |
| yfinance | **Unofficial** Yahoo wrapper; ToS-gray | Acceptable for personal/family use; **must be replaced by a licensed source (EODHD or similar) before any public/commercial exposure** — recorded as a Phase 7+ gate condition |
| Media RSS (LiveMint, BS, ET) | Public feeds | Headlines+links ingestion is standard practice; never republish article bodies in the UI — events feed shows title + link + our synthesis, not their text |
| niftyindices.com TRI | Public CSVs | Personal use fine; licensed index data required if public |
| casparser (CAS PDFs) | MIT lib; the CAS is the user's own document | Clean |

## Regulatory Posture (restating the locked decisions)
Personal + family/friends; recommendations only; no execution, ever (ADR/Spec Q12). Disclaimer component on every signal/recommendation surface (Invariant 12): informational/educational, not investment advice, no SEBI registration claimed or implied. Name + all copy avoid "advisor/advisory/assured/guaranteed" (NAMING.md guardrails). Public expansion = separate compliance project (SEBI RA/IA evaluation) — the F8 architecture keeps the door open; the product does not walk through it uncleared.

## Cost Optimization Playbook (6A rider — cut costs, maximize quality)

**LLM (the only meaningful variable cost):**
1. **Batches API for synthesis** (`llm.use_batch_api=true`): non-urgent events (anything not touching a held instrument) go through Anthropic's batch endpoint at **−50% cost**; held-instrument events stay realtime. Synthesis is async-tolerant by design — this is nearly free money.
2. **Prompt caching** on the stable prompt prefix (system + dependency-graph neighborhood): repeated synthesis calls share cached context — large input-token savings since the graph dwarfs the event text.
3. **Tiered models**: Haiku-class for Stage-2 relevance (already configured), Sonnet-class for Stage-3 synthesis; never Opus-class in the pipeline.
4. **Pre-filter ratio is the real lever**: every point of Stage-2 precision is multiplied savings at Stage 3. Track `synthesis_results.cost_usd` weekly; if cost/relevant-event rises, tune the entity matcher before raising the budget.
5. **Hard daily cap** (`llm.daily_budget_usd`) + queue-don't-drop = worst case is delay, never surprise bills.
6. Expected: $10–25/mo realistic; $93/mo absolute ceiling at default cap.

**Infra:**
7. Worker on **Fly.io autostop** (scale-to-zero between scheduled runs) if cadences allow gaps, else Railway flat ~$5/mo — pick at deploy, both pre-approved.
8. Local embeddings (ADR-008) = $0 forever on the highest-volume call class.
9. Supabase free tier: 500MB DB / 1GB Storage — EOD-for-full-universe fits for years (≈2.5k instruments × 250 days × ~60B/row ≈ 40MB/yr); intraday pruning (retention.intraday_days) keeps the hot table flat. First paid trigger will be Storage from news archives — archive compression buys years.
10. Vercel free tier holds at family scale; no image-heavy assets.

**Data:**
11. Free-first doctrine stands; **EODHD (~$20/mo) is the only near-term paid candidate**, added on Phase 2.7 evidence of fundamentals gaps — and it simultaneously retires the yfinance ToS-gray note above, a two-birds purchase when the time comes.
12. Frequency-follows-attention (DATA_SOURCES) means cost scales with *holdings*, not users or universe.

**Quality-per-rupee:**
13. The 12-month walk-forward backfill (Phase 3.8) is the cheapest credibility purchase in the program — compute-only, no data cost, and it converts "trust me" into a measured ledger at launch.
