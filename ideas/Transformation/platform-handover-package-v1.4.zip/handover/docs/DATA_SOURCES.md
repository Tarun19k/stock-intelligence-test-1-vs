# DATA_SOURCES.md — Catalog, Frequencies, Validation

Machine-readable seed: `config/sources.seed.json` (loaded into `sources` + `admin_config` in Phase 0.2). This doc is the rationale; the seed is the truth at runtime. Frequencies live in admin_config — the table below is defaults, not law.

## Active Sources (Phase 0–4)

| source_id | family | What | Default cadence | Validation gate checks |
|---|---|---|---|---|
| `yahoo` | prices, fundamentals | EOD+delayed quotes, fundamentals IN+US | slice/held: 5min mkt-hrs (quotes); EOD daily | MultiIndex flattening (GSI C-003), ROE None-guard (C-004), close>0, date monotonic |
| `bhavcopy_nse` / `bhavcopy_bse` | prices | official full-universe EOD files | daily post-close (~7pm IST) | row count vs universe ±10%, ISIN join rate >95% |
| `amfi` | navs | all MF NAVs (NAVAll.txt) | daily ~21:30 IST | scheme count sanity, NAV>0, date=today-ish |
| `masters_nse` / `masters_bse` / `masters_amfi` | masters | security/scheme master files → dynamic universe | weekly | schema stability, delta report (new/delisted logged) |
| `rss_rbi`, `rss_sebi`, `rss_pib`, `rss_exchanges`, `rss_financial` | news | policy + curated financial RSS (allowlist pattern ported from GSI) | 30 min | allowlisted domains only, published_at parseable, dedupe key |
| `filings_nse` | filings | corporate announcements | hourly | symbol resolves to instrument |
| `gdelt` | news | global event stream | hourly, aggressive pre-filter | language=en, themes allowlist, volume cap/run |
| `fred`, `datagovin` | macro | rates, CPI, IIP, USDINR | daily | series continuity, no future dates |

## Paid Slots (reserved, disabled in seed)

| source_id | When to enable | ~Cost |
|---|---|---|
| `eodhd` | fundamentals coverage gaps found in Phase 2.7 | ~$20/mo |
| `marketaux` | when raw-RSS LLM classification cost > entity-tagged feed cost (watch synthesis_results.cost_usd) | $0–25/mo |
| `polygon` | only if US intraday becomes a requirement | $29+/mo |

Enabling a paid source = flip `enabled`, add credentials to worker secrets, set cadence keys. Zero code if the adapter exists; new adapter otherwise (one module, Invariant 2).

## The Ingest-to-Local-Store Doctrine (operational form)
1. Workers call out on schedule; the app never does (Invariant 3).
2. Every fetch runs inside an `ingestion_run`; failures mark the run failed and **leave prior data standing** — staleness is shown, never hidden (`fetched_at` surfaces in the UI as a freshness stamp).
3. Frequency follows attention: held+watchlist instruments get the fast tiers; the full universe gets daily. Adding users adds zero external-API cost.
4. Rate-limit state is checked **before** every adapter call (Invariant 5).
5. Conflicting sources (e.g., bhavcopy vs yahoo close differing >0.5%): bhavcopy (official) wins; conflict logged to ingestion_run.error as `partial`; policy per pair lives in admin_config `reconciliation.*`.

## Retention
intraday 7d (config) · EOD/NAV/macro permanent · news hot 90d then archived to Storage · fundamentals versioned snapshots permanent · ingestion_runs 180d.
