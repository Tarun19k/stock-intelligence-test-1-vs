# BUILD_PLAN.md — Phases, Items, Gates

> Sequence authority. Work top-down; check items off in-place. Phase exit = CI green + QA brief + Tarun gate sign-off (ADR row). Max 9 items per phase. Within a phase, Claude Code proceeds autonomously.

## Phase 0 — Scaffold & Donor Port
- [ ] 0.1 Monorepo skeleton per ARCHITECTURE.md; pyproject (Python 3.12, ruff, pytest); Next.js + TS + Playwright init; CI workflow (pytest, playwright, sweeps)
- [ ] 0.2 Supabase local via CLI; apply `migrations/0001_init.sql`; load `config/sources.seed.json`
- [ ] 0.3 Port GSI pure core per docs/GSI_DONOR_AUDIT.md §PORT: indicators, portfolio math, forecast engine math, calc/sanitise — with pytest for each (target: port + tests, no behavior change)
- [ ] 0.4 `tools/hardcode_sweep.py` + `tools/purity_check.py` wired into CI
- [ ] 0.5 `engine/store` repositories + provenance writer + ingestion_run lifecycle
- [ ] 0.6 Rate-limit module (port GSI pattern, process-local state, pre-call check)
- [ ] 0.7 WIP.md protocol live; docs/DECISIONS.md seeded with ADR-001 (monorepo), ADR-002 (Python 3.12), ADR-003 (governance scope)
**Gate G0:** CI green; core ported with passing tests; local stack boots end to end.

## Phase 1 — Vertical Slice (one ticker proves the pipe)
Slice instrument: RELIANCE.NS (admin_config key `slice.instrument`, not hardcoded).
- [ ] 1.1 Yahoo adapter (port GSI `_yf_download`/`_normalize_df` incl. C-003/C-004 fixes) behind rate-limit
- [ ] 1.2 EOD ingestion job for the slice instrument → prices_eod with provenance
- [ ] 1.3 Signal computation job: ported indicators → signals row
- [ ] 1.4 Web: instrument page reading store only — price chart, current signals, freshness stamp, Disclaimer component
- [ ] 1.5 Playwright E2E: page renders signal computed from ingested data
- [ ] 1.6 Scheduler: APScheduler inside the worker is THE single scheduler (ADR-006); jobs read cron/cadence keys from admin_config
- [ ] 1.7 Failure visibility: daily run-health digest + optional webhook on failed runs (admin_config alerts.*; GAP-13)
**Gate G1:** demo — external source → store → signal → UI, zero request-time external calls (verified by network assertion in E2E).

## Phase 2 — Universe & Portfolio Ingestion
- [ ] 2.1 Universe masters: NSE/BSE security files + AMFI scheme master, weekly job → instruments table (dynamic universe; delisting flags)
- [ ] 2.2 Full-universe EOD via bhavcopy adapter (primary) with yahoo fallback; AMFI NAV daily job
- [ ] 2.3 Held/watchlist quote tier (5-min, market hours, config-gated)
- [ ] 2.4 CSV/Excel portfolio parser → holdings; mapping UI for unmatched symbols
- [ ] 2.5 CDSL CAS PDF statement parser (best-effort v1; unmatched rows go to mapping UI)
- [ ] 2.6 Portfolio dashboard: positions, allocation, P&L, per-holding signal chips
- [ ] 2.7 Watchlist CRUD; fundamentals weekly job (yahoo; EODHD slot reserved)
- [ ] 2.8 Corporate actions: ingestion (splits/bonus/dividends/IDCW) -> corporate_actions + price_adjustments; P&L uses adjusted series (migration 0002; GAP-06)
- [ ] 2.9 Market calendar job (NSE holidays -> market_calendar; sessions from admin_config) gating all market-hours schedules (GAP-07). CAS parsing evaluates `casparser` (MIT) before hand-rolling (GAP-16)
**Gate G2:** Tarun's real portfolio loads and renders correctly; spot-check vs broker app.

## Phase 3 — Forecasting & Accuracy Ledger
- [ ] 3.1 Horizon runners (1W/1M/3M via ported bootstrap engine; 1Y statistical ensemble; 3Y scenario ranges) per docs/FORECAST_ACCURACY.md
- [ ] 3.2 Forecast persistence with inputs hash; nightly batch for held + watchlist
- [ ] 3.3 Scoring jobs on realization; accuracy ledger writes
- [ ] 3.4 Threshold evaluation + auto-demotion flags (Spec §2 table)
- [ ] 3.5 Web: forecast tab (bands, horizon switcher, confidence labels) + Accuracy page (the ledger, public to users)
- [ ] 3.6 Benchmark ingestion: NIFTY 50 TRI series (niftyindices source) feeding alpha thresholds (GAP-04)
- [ ] 3.7 Nightly pg_dump backup job to Storage, 30-day rotation + one restore drill (GAP-14)
- [ ] 3.8 Backfill harness: run engine on trailing 12 months to seed the ledger before go-live judgments
**Gate G3:** ledger populated from backfill; demotion behavior visible; Tarun reviews calibration.

## Phase 4 — News & Synthesis Layer
- [ ] 4.1 RSS/policy-feed adapters (RBI, SEBI, PIB, exchanges, curated financial RSS from seed) + filings poller
- [ ] 4.2 GDELT adapter behind aggressive pre-filter
- [ ] 4.3 Dedupe/cluster (pgvector embeddings)
- [ ] 4.4 Dependency graph v1: instrument↔sector↔commodity↔policy-domain mapping tables + seed
- [ ] 4.5 Relevance filter (entity match + small-model call) with per-day LLM budget in admin_config
- [ ] 4.6 LLM synthesis stage (Anthropic API) per docs/SYNTHESIS_PIPELINE.md prompts; materiality gate; signal updates + signal_audit rows
- [ ] 4.7 Web: events feed, per-instrument "why did this signal change" trace view
**Gate G4:** mining-policy-style test from Spec §9.3 passes on both a real and a tool-created portfolio.

## Phase 5 — Rebalancing & Alpha
- [ ] 5.1 Regime detector (config-driven thresholds) feeding advise engine
- [ ] 5.2 Rebalance engine: cvxpy port + constraints from admin_config; outputs trim/add/exit/hedge/hold with sizing + rationale
- [ ] 5.3 Alpha discovery: factor/event/valuation screens over store; evidence trail per candidate
- [ ] 5.4 Recommendations UI with rationale, counterfactual note, Disclaimer; recommendation audit rows
- [ ] 5.5 Efficacy tracking wiring (post-rec Sharpe vs counterfactual → ledger)
**Gate G5:** recommendations reviewed against Tarun's judgment on the real portfolio for one full cycle.

## Phase 6 — Design System & UX Elevation
Inputs: Tarun's references/brand direction (Q4-A — collected before this phase starts; design brief written then).
- [ ] 6.1 docs/DESIGN_BRIEF.md from references; tokens (color/type/spacing) as theme config
- [ ] 6.2 Component library pass; navigation IA finalization; mobile responsiveness
- [ ] 6.3 Full Playwright behavioral suite expansion (the regression baseline of this platform)
- [ ] 6.4 Empty/loading/error states; freshness stamps everywhere; onboarding flow
**Gate G6:** UX review with Tarun; Playwright suite is the accepted regression baseline.

## Phase 7 — Hardening & Family Exposure
- [ ] 7.1 Prod environment cutover per ENV_SETUP; pg_cron/scheduler hardening; alerting on failed ingestion_runs
- [ ] 7.2 Auth exposure: invite flow for family/friends; RLS audit; admin role separation
- [ ] 7.3 Compliance pass: disclaimers on all surfaces, no advisory-registration implications, naming finalized (docs/NAMING.md decision)
- [ ] 7.4 Load/backup/restore drill; secrets rotation runbook
- [ ] 7.5 Chaos test: kill an upstream source, verify stale-stamped serving (SPEC 9.6; GAP-17)
**Gate G7:** first external user invited.

## Standing Rules
- Phases are sequential; items within a phase may interleave if dependencies allow.
- New scope mid-phase → backlog section below + ADR, never silent insertion.
- Every gate produces: QA brief (screenshots + nav steps), ledger/CI snapshot, ADR sign-off row.

## Backlog (post-G7 candidates)
EODHD integration · bonds/gold/FD asset classes · US intraday tier · multi-provider LLM config · public-product compliance track · mobile PWA.
