# ENV_SETUP.md — Accounts, Keys, Walkthrough

## Checklist (what Tarun provides)
- [ ] **Supabase**: create project (region: ap-south-1 Mumbai). Capture: project URL, anon key, service-role key. Enable pgvector (Dashboard → Database → Extensions).
- [ ] **Vercel**: account + connect the GitHub repo (web/ as root directory).
- [ ] **Railway** (or Fly.io): account for the worker. ~$5/mo plan.
- [ ] **Anthropic API**: key for synthesis pipeline (set a monthly spend limit in console ≥ llm.daily_budget_usd × 31).
- [ ] **GitHub**: new repo created; Actions enabled.
- [ ] Test fixtures: one real broker CSV export + one CDSL CAS PDF (redacted copies fine) into `worker/tests/fixtures/` — Phase 2 parsers are built against these.

## Secrets Map (never in repo)
| Secret | Lives in |
|---|---|
| SUPABASE_URL, SUPABASE_ANON_KEY | Vercel env + worker env + local .env |
| SUPABASE_SERVICE_ROLE_KEY | worker env ONLY (never Vercel, never web) |
| ANTHROPIC_API_KEY | worker env only |
| INTERNAL_SHARED_SECRET | worker env + Vercel env (web→worker endpoints) |

## Walkthrough
**Local (day one):**
1. `npm i -g supabase` → `supabase init` → `supabase start` (local Postgres+Auth in Docker).
2. `supabase db push` applies `supabase/migrations/`.
3. `cd worker && uv venv && uv pip install -e .[dev]` → `python -m engine.ingestion.seed_loader config/sources.seed.json`.
4. `pytest` (unit) — green before anything else.
5. `cd web && npm i && npm run dev` against local Supabase URL/keys.
6. Worker scheduler locally: `python -m engine.jobs --once eod_slice` to hand-run jobs while developing.

**Staging→Prod:**
1. Supabase cloud project → `supabase link` → `supabase db push`.
2. Run seed loader against cloud (service key in local env for the one-time run).
3. Railway: new service from repo `worker/`, set env vars, deploy; verify ingestion_runs rows appear.
4. Vercel: import repo, root `web/`, set env vars, deploy preview → promote.
5. Smoke: instrument page shows data with freshness stamp; admin page shows green runs.

**CI (GitHub Actions, Phase 0.1):** on PR — ruff, pytest (with supabase local service container), Playwright against a preview build, `tools/hardcode_sweep.py`, `tools/purity_check.py`. Merge blocked on red.

## Cost Expectation (Phase 0–4)
Supabase free tier · Vercel free tier · worker ~$5/mo · Anthropic ≤ daily budget (default $3/day cap ≈ $90/mo worst case; realistic with pre-filter: $10–25/mo) · data $0. First paid data add: EODHD ~$20/mo, only on Phase 2.7 evidence.
