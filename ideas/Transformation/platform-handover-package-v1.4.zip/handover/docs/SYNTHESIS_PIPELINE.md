# SYNTHESIS_PIPELINE.md — Event → Impact → Signal

The differentiator (Spec F6). Five stages; the LLM is the scalpel, not the conveyor belt. All knobs are admin_config keys (`llm.*`, `synthesis.*`).

## Stage 1 — Dedupe & Cluster
New `events` rows get embeddings (`synthesis.embedding_model`); cosine-similar items within 48h cluster to a representative (`cluster_id`). Only cluster representatives proceed. Cost: ~zero (local embedding model in the worker; pgvector search).

## Stage 2 — Relevance Filter (cheap)
Two passes, both must agree to ADVANCE:
1. **Entity/graph match:** does the event text match any instrument name/symbol, sector keyword, or `dependency_edges` from_key (policy domain, commodity)? Pure-Python matcher against the graph.
2. **Small-model check** (`llm.relevance_model`): one short call — "Could this plausibly affect listed Indian/US instruments or these sectors: {graph snapshot}? YES/NO + domains touched." Hard daily call cap.
Outcome → `events.relevance = 'relevant' | 'dropped'`. Expected survival rate: 10–20% of clusters.

## Stage 3 — LLM Synthesis (expensive, survivors only)
Model: `llm.synthesis_model`. Budget: every call's cost written to `synthesis_results.cost_usd`; running daily total checked against `llm.daily_budget_usd` BEFORE each call — over budget, events queue for tomorrow (graceful degradation, never silent drop).

Prompt contract (template lives at `worker/src/engine/synthesis/prompts/synthesize.md`):
- **Inputs:** event title+body, the relevant dependency-graph neighborhood (edges + instruments), current signals for touched instruments, held/watchlist flags.
- **Required output (JSON):**
```json
{
  "affected": [{
    "instrument_ref": "NSE:RELIANCE",
    "direction": "up|down|mixed",
    "magnitude": 0.0-1.0,
    "confidence": 0.0-1.0,
    "channel": "direct|supply_chain|input_cost|regulatory|sentiment",
    "rationale": "two sentences max, cites the event",
    "horizon_bias": "1W|1M|3M|1Y"
  }],
  "proposed_edges": [{"from_kind":"...","from_key":"...","to_kind":"...","to_key":"...","relation":"...","direction":1,"note":"..."}],
  "non_obvious": "second-order effects worth admin attention, or null"
}
```
- Hallucination guard: every `instrument_ref` must resolve against the instruments table; unresolved refs are logged and dropped, never guessed.

## Stage 4 — Materiality Gate
`score = confidence × magnitude` per affected instrument. Only entries with `score ≥ synthesis.materiality_min` update signals — Spec F6's "update only when deemed necessary" made mechanical. Sub-threshold results are still stored in `synthesis_results` (visible in the event feed as "noted, not material").

## Stage 5 — Signal Update + Audit
For each material entry: UPSERT `signals(instrument_id,'event_impact')` merging direction/magnitude/decay; INSERT `signal_audit` row with `trigger_kind='event_synthesis'`, `trigger_ref=synthesis_results.id`. Event-impact signals **decay**: half-life per channel in admin_config (`synthesis.halflife_days.*`) so stale news doesn't pin signals forever; nightly decay job re-evaluates.

`proposed_edges` land in dependency_edges with a `pending` note for admin approval via the admin UI (human approves graph growth; LLM only proposes).

## Worked Example (the Spec §9.3 acceptance test)
"Cabinet approves changes to mining royalty structure" →
S1: clusters 6 outlet copies to one representative. S2: graph match hits `policy_domain:mining` edges → miners (direct), metal consumers (input_cost), capital-goods suppliers (supply_chain); small model: YES. S3: synthesis returns Coal India ↑ (direct, 0.7×0.8), Hindalco ↓ (input_cost, 0.5×0.6), an unheld mining-services firm ↑ flagged as alpha-relevant. S4: all clear 0.35. S5: three signal updates + audit rows; alpha candidate forwarded to the advise engine; the UI trace view shows event → reasoning → delta for each.

## Failure Modes & Handling
- LLM API down → events queue with `relevance='relevant'`, retried next cycle; signals stand with freshness stamps.
- Malformed JSON → one repair retry, then dead-letter to `synthesis_results` with `materiality_passed=false` + error in affected, surfaced on admin page.
- Budget exhausted → queue; admin page shows backlog depth.
- Prompt-injection via news body: synthesis prompt instructs treating event text strictly as data; output schema validation + instrument-resolution guard bound the blast radius; no tool use inside synthesis calls.
