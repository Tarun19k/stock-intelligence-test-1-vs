# Prompt Specification — Personal Investment Intelligence & Planning Platform

**Status:** v1.0 — DECISIONS LOCKED · ready for architecture design phase
**Supersedes:** v0.1 (2026-06-11) · **Decisions recorded:** 2026-06-11
**Relationship to GSI:** New platform. GSI is the donor codebase (algorithms,
data-layer patterns, governance discipline). New design system, new layouts,
new color themes, materially upgraded UI/UX.

---

## 0. Decision Register (all 15 questions resolved)

| # | Question | Decision |
|---|---|---|
| 1 | Platform identity | **New platform, GSI as donor** — port `gsi/core` algorithms (indicators, portfolio math, forecast engine) and data-layer patterns; everything user-facing is new |
| 2 | Asset classes | **Phase 0: listed equities + MF/ETFs.** Future-state: bonds/FDs, gold, real estate, unlisted (architecture must not preclude) |
| 3 | Data budget | **Ingest-to-local-store strategy** (§3) — controlled-frequency pulls into owned storage; app reads only from store. Free-tier first, paid sources added where the value table justifies |
| 4 | v1 users | **Tarun + family/friends (tens).** Public expansion only after algorithm validation AND compliance/regulatory clearance |
| 5 | Hosting | **Vercel + Supabase + small Python worker** (§4) |
| 6 | Portfolio input | **CSV/Excel upload + broker statement parsing** (Zerodha/CDSL CAS). Manual entry as fallback |
| 7 | Markets | **India core (NSE/BSE full universe + AMFI MFs) + US layer.** No execution — broker apps handle trades. Ticker universe is itself dynamic (§3.4); static entries are a defect |
| 8 | Horizons | **All five: 1W · 1M · 3M · 1Y · 3Y** |
| 9 | Accuracy bar | **Proposed thresholds adopted (§2)** — measurable, gating, auto-demotion below threshold |
| 10 | News cadence | **Daily polling baseline** (intraday tiers available per §3.3 frequency table, off by default) |
| 11 | Synthesis brain | **LLM-powered interpretation from day one**, behind a materiality pre-filter (§5) |
| 12 | Execution | **Recommendations only, permanently.** No broker integration, ever |
| 13 | Future scale | Tens now; thousands considered later — auth/data model built multi-user from day one (F8) |
| 14 | Language | **Python core** (computation, ingestion, synthesis orchestration) + **TypeScript** (UI on Vercel). No further polyglot unless a phase demands it |
| 15 | Admin config | **Database-backed config (Supabase) + admin UI page.** Schema versioned in repo; values live in DB |

---

## 1. Mission Statement

An investment planning platform built on **accuracy, a validated data chain,
and user-friendliness** — solving **personal finance first**. It models every
holding in an existing or newly created portfolio in depth, forecasts across
five horizons, surfaces alpha with evidence, recommends concrete rebalancing
actions, and continuously re-evaluates everything as real-world events flow
through an LLM-powered interpretation and synthesis layer. Recommendations
only — investments are executed in the user's broker app.

---

## 2. Accuracy Thresholds (Q9 — adopted proposal)

Accuracy is measured, published in-app, and **gating**: a signal class that
falls below threshold is automatically demoted to an "informational —
low confidence" presentation until it recovers. No silent display of
underperforming signals.

| Metric | Threshold | Window | Applies to |
|---|---|---|---|
| Directional hit-rate (1W, 1M) | ≥ 60% | rolling 12 weeks | price-direction signals |
| Directional hit-rate (3M, 1Y) | ≥ 65% | rolling 26 weeks | medium/long forecasts |
| Band calibration | 80% band contains realized price 75–85% of the time | rolling 12 weeks | all forecast bands |
| Alpha cohort excess return | ≥ +2% annualized vs NIFTY 50 TRI | rolling 6-month cohorts | F3 recommendations |
| Alpha hit-rate | ≥ 55% of recommendations beat benchmark | rolling 6-month cohorts | F3 recommendations |
| Rebalance efficacy | post-recommendation 3M portfolio Sharpe ≥ counterfactual (no-action) Sharpe | per recommendation, aggregated quarterly | F4 |
| 3Y horizon | explicitly **not** point-accuracy gated — scenario ranges with assumptions disclosed | — | long-horizon planning |

Every forecast is persisted at creation with its inputs hash; scoring jobs
run on realization. The accuracy ledger is itself a user-visible page
(chain-of-validation made tangible).

---

## 3. Data Sourcing Strategy (Q3 — full options analysis)

### 3.1 The pattern: Ingest-to-Local-Store (adopted)

```
[External sources] → scheduled ingestion workers (frequency per data class)
                   → validation gate (schema, freshness, sanity checks)
                   → Supabase Postgres (+ Storage for blobs)
                   → provenance stamp (source, fetch_ts, checks_passed, lineage)
                   ⇣
[App / synthesis layer] reads ONLY from the local store — never external APIs
```

Why this wins on every axis you care about:
- **Cost control:** external API call volume is fixed by *your* schedule, not
  by user activity. Adding 10 users adds zero API cost.
- **Rate-limit immunity:** the GSI 429-death-spiral failure class becomes
  structurally impossible — the app cannot stampede an upstream.
- **Validation chain:** the ingestion gate is the single chokepoint where
  every datum earns its provenance stamp (E3).
- **Subscription leverage:** a paid source polled at controlled frequency
  amortizes across all users and all features reading the store.
- **Graceful degradation:** upstream outage = stale-but-served data with a
  visible freshness stamp, not a broken app.

### 3.2 Source catalog

**Free tier (Phase 0 backbone)**

| Source | Data | Notes |
|---|---|---|
| yfinance | EOD + delayed quotes, fundamentals (IN + US) | proven in GSI; known quirks (C-003/C-004 class) travel with the adapter |
| NSE/BSE bhavcopy | official EOD OHLCV, full universe | authoritative; daily file ingestion |
| AMFI NAVAll | all Indian MF NAVs daily | the canonical free MF source |
| RBI / SEBI / PIB / Ministry RSS | policy & regulatory events | feeds the synthesis layer's India policy coverage |
| GDELT 2.0 | global event stream, free | broad macro/news radar; noisy — pre-filter essential |
| Exchange/registrar corporate announcements (NSE/BSE filings) | earnings, actions, disclosures | high-signal synthesis input |
| FRED / data.gov.in | macro series | rates, inflation, IIP etc. |

**Paid candidates (added only when a capability demands it)**

| Source | ~Cost | What it unlocks | Verdict |
|---|---|---|---|
| EODHD All-World | ~$20/mo | clean EOD + fundamentals + corporate actions, IN+US, generous limits | **best value first paid add** |
| Marketaux / NewsData.io | $0–25/mo tiers | entity-tagged financial news (ticker-mapped) | strong synthesis accelerator — entity tagging saves LLM cost |
| Polygon.io | $29+/mo | US real-time/minute bars | only if US intraday becomes a requirement |
| Tickertape/Screener-class IN fundamentals | varies | deeper Indian fundamentals | evaluate after EODHD gap analysis |
| TrueData / Global Datafeeds | ₹1k+/mo | Indian real-time ticks | **not needed** — recommendations platform, not a trading terminal |

Pricing is indicative and must be re-verified at procurement time.

**Decision rule:** start 100% free tier; add EODHD when fundamentals
coverage gaps appear; add an entity-tagged news API when synthesis volume
makes raw-RSS LLM classification the larger cost. Each addition is an
admin-config change (new source row + credentials + schedule), zero code.

### 3.3 Frequency tiers (admin-configurable, these are defaults)

| Data class | Pull frequency | Store TTL / retention |
|---|---|---|
| Live-ish quotes (held + watchlist only) | 5 min, market hours only | latest + intraday day-store |
| EOD prices (full universe) | once daily post-close | permanent history |
| MF NAVs (AMFI) | once daily (~9pm IST publish) | permanent |
| Fundamentals | weekly + on-event (earnings filing detected) | versioned snapshots |
| News/RSS/policy feeds | 15–30 min | 90-day hot, archive after |
| Corporate filings | hourly | permanent |
| Macro series | daily | permanent |
| Ticker/scheme master files | weekly | versioned (this is what makes the universe dynamic) |

Note the cost asymmetry this creates: *quotes for the ~50 tickers users
actually hold* refresh every 5 minutes; the *full 2,000+ universe* refreshes
once daily. Frequency follows attention.

### 3.4 Dynamic universe (Q7 "no static entries")

The instrument universe is data, not code: NSE/BSE security master files and
the AMFI scheme master are ingested weekly into the store. New listings
appear automatically; delistings are flagged on held positions. `tickers.json`
has no successor.

---

## 4. Platform Architecture Decision (Q5)

**Adopted: Vercel + Supabase + small always-on Python worker.**

| Component | Role |
|---|---|
| **Vercel** (Next.js/TypeScript) | UI, light API routes, auth session handling. New design system lives here — full control over layout/theme that Streamlit never allowed |
| **Supabase** | Postgres (portfolios, signals, accuracy ledger, admin config, provenance), Auth (F8 multi-user from day one), Storage (statements, bhavcopy archives), pg_cron (schedule triggers), Row-Level Security (per-user portfolio isolation) |
| **Python worker** — Railway or Fly.io, ~$5/mo | ingestion jobs, validation gate, synthesis pipeline (LLM orchestration), forecasting batch runs, cvxpy optimization. This is where the GSI-donated `gsi/core` code lives |

**Why not the alternatives (5C analysis):**

- *Streamlit Cloud alone:* no scheduled workers, filesystem wiped on deploy,
  no real auth — fails F5/F7/F8 structurally. Retired with honor.
- *Vercel-only (Python serverless functions):* cold starts + duration limits
  punish cvxpy and batch forecasting; cron functions can't hold long jobs.
  Fine for light API, wrong for the compute spine.
- *GitHub Actions as the worker:* free and tempting, but 15-min schedule
  granularity floor in practice, no mid-job state, awkward secrets surface
  for an LLM pipeline. Acceptable emergency fallback only.
- *Render/Fly vs Railway:* near-equivalent; pick at build time on DX/pricing
  that month. The architecture is identical.

Estimated steady-state cost, Phase 0: **$5–10/mo** (worker) + LLM synthesis
spend (§5) + $0 data. Supabase and Vercel free tiers hold at tens of users.

---

## 5. Synthesis Layer Cost Control (Q11 rider)

LLM-from-day-one is adopted, with a **materiality pre-filter** so the LLM is
the scalpel, not the conveyor belt:

```
event in → (1) dedupe/cluster (embeddings or minhash, near-zero cost)
         → (2) cheap relevance classifier: does this touch any held instrument,
               watchlist member, or mapped sector/supply-chain node?
               (keyword/entity match against the dependency graph + small-model call)
         → (3) ONLY survivors get full LLM synthesis: direction, magnitude,
               confidence, affected-instrument list, rationale
         → (4) materiality threshold: signal updates only when synthesis
               confidence × magnitude clears the admin-configured bar
         → (5) every signal change writes an audit row: event → reasoning → delta
```

Expected effect: 80–90% of raw headlines never reach the expensive call.
Model choice, thresholds, and per-day call budget are admin config (Q15).

---

## 6. Capability Requirements (carried from v0.1, unchanged in substance)

F1 Portfolio ingestion & deep instrument understanding (now: CSV/Excel +
broker statement parsing; equities + MF/ETF) · F2 Five-horizon forecasting
with persisted, scored predictions · F3 Alpha discovery with evidence trail ·
F4 Regime-aware rebalancing recommendations · F5 Scheduled news/event
ingestion from the admin-extensible source catalog (§3.2) · F6 LLM synthesis
with dependency-graph impact propagation (§5) · F7 Zero-hardcoding doctrine —
every value is dynamic-with-TTL or DB-backed admin config · F8 Multi-user
auth/state from day one (Supabase Auth + RLS), UI exposure gated to
family/friends until compliance review.

## 7. Engineering Directives (carried, with Q-informed updates)

- **E1 Consolidation audit** targets the GSI repo *as donor*: identify which
  modules port (indicators, portfolio math, forecast engine, rate-limit and
  adapter patterns), which retire (Streamlit-coupled UI, fragments, CSS
  hacks), and which GSI learnings become platform invariants (single-adapter
  rule, sanitise chokepoint, audit-trail immutability).
- **E2 Stack:** Python worker + TypeScript UI (locked, Q14). Library matrix
  due in design phase (candidates: Polars vs pandas at ingestion; Prophet/
  statsforecast/sktime + the GSI bootstrap engine for F2; cvxpy retained for
  F4; pgvector for event dedupe).
- **E3 Chain of validation:** provenance stamp written at the §3.1 ingestion
  gate; reconciliation policy per source pair defined in admin config.

## 8. Compliance Posture (locked)

Personal + family/friends use; recommendations only; no execution pathway,
permanently (Q12). Every signal page carries the educational/informational
disclaimer (GSI Rule 12/13 discipline ports as a UI component). Public
expansion is a separate future project gated on SEBI IA/RA review — the
codebase keeps that door open (F8) but the product does not walk through it.

## 9. Acceptance & Test Plan

1. Ingest Tarun's real portfolio (CSV + CAS) → full F1–F4 coverage reviewed.
2. Create a fresh portfolio in-tool → identical coverage.
3. Inject a real policy event (e.g., a mining policy update) → synthesis
   updates the correct instruments in both portfolios, correct direction,
   visible rationale, audit row written.
4. Hardcoding sweep: automated check finds zero non-config static values.
5. Accuracy ledger live; §2 thresholds wired to demotion behavior.
6. Kill an upstream source → app serves stale-stamped data, no failure.

## 10. Next Step

Architecture design phase (deliverables 1–9 from v0.1 §8), opening with the
E1 donor audit of GSI and the Supabase schema for portfolios, provenance,
signals, accuracy ledger, and admin config.
