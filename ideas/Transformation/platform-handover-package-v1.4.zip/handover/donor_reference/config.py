# config.py
# Depends on: version.py (re-export), tickers.json (data)
# Called from: all modules
# Contains: ONLY constants, session config, and help text.
#            Ticker data lives in tickers.json.
#            Version history lives in version.py.
# Zero Streamlit calls.

import json
import os
from version import VERSION_LOG, CURRENT_VERSION  # re-exported for back-compat

# ── Ticker data ───────────────────────────────────────────────────────────────
# Load once at import time from tickers.json (same directory as this file).
# All modules that do `from config import GROUPS` continue to work unchanged.
_TICKERS_PATH = os.path.join(os.path.dirname(__file__), "tickers.json")
try:
    with open(_TICKERS_PATH, encoding="utf-8") as _f:
        GROUPS: dict = json.load(_f)
except FileNotFoundError:
    GROUPS = {}
    import warnings
    warnings.warn(
        f"tickers.json not found at {_TICKERS_PATH}. GROUPS will be empty.",
        RuntimeWarning,
        stacklevel=2,
    )
except json.JSONDecodeError as _e:
    GROUPS = {}
    import warnings
    warnings.warn(
        f"tickers.json is malformed: {_e}. GROUPS will be empty.",
        RuntimeWarning,
        stacklevel=2,
    )

# ── Market sessions ───────────────────────────────────────────────────────────
MARKET_SESSIONS: dict = {
    "India":          {"tz": "Asia/Kolkata",      "open": (9,  15), "close": (15, 30)},
    "USA":            {"tz": "America/New_York",   "open": (9,  30), "close": (16,  0)},
    "Europe":         {"tz": "Europe/London",      "open": (8,   0), "close": (16, 30)},
    "China":          {"tz": "Asia/Hong_Kong",     "open": (9,  30), "close": (16,  0)},
    "ETFs - India":   {"tz": "Asia/Kolkata",       "open": (9,  15), "close": (15, 30)},
    "ETFs - Global":  {"tz": "America/New_York",   "open": (9,  30), "close": (16,  0)},
    "Commodities":    {"tz": "America/New_York",   "open": (8,   0), "close": (17, 30)},
    "Debt & Rates":   {"tz": "America/New_York",   "open": (8,   0), "close": (17,  0)},
    "Global Indices": {"tz": "Asia/Kolkata",       "open": (9,  15), "close": (15, 30)},
}

# ── Currency symbols ──────────────────────────────────────────────────────────
CURRENCY: dict = {
    "India":          "₹",
    "USA":            "$",
    "Europe":         "€",
    "China":          "¥",
    "ETFs - India":   "₹",
    "ETFs - Global":  "$",
    "Commodities":    "$",
    "Debt & Rates":   "%",
    "Global Indices": "Pts",
}

# ── Forecast persistence ──────────────────────────────────────────────────────
# Used by forecast.py. On Streamlit Cloud this file will not persist across
# redeploys; forecast.py handles graceful degradation to session_state.
FORECAST_STORE_FILE: str = "forecast_history.json"

# ── Global Intelligence topics ────────────────────────────────────────────────
GLOBAL_TOPICS: dict = {
    "🔴 West Asia Conflict": {
        "color": "#ff4444",
        "subtitle": "Geopolitical Crisis · Supply Chain · Consumer Impact",
        "overview": (
            "The ongoing conflict across West Asia is reshaping global trade routes, "
            "energy supply chains, and inflationary pressures — with second and third-order "
            "effects felt from crude oil desks in Mumbai to grocery shelves worldwide."
        ),
        "chain": [
            ("Active Conflict Zones",    "#7f0000", "Direct military engagement in Gaza, Lebanon, Red Sea"),
            ("Regional Destabilisation", "#b71c1c", "Iran–Israel tensions, Houthi Red Sea attacks"),
            ("Oil & Energy Supply Risk", "#c62828", "Strait of Hormuz risk premium, Brent spike"),
            ("Shipping Route Disruption","#d32f2f", "Suez Canal diversions → +14 days transit → +30% freight"),
            ("Global Energy Inflation",  "#e53935", "Fuel, fertiliser, plastics cost surge"),
            ("Supply Chain Repricing",   "#ef5350", "Electronics, autos, agriculture inputs"),
            ("Consumer Goods Costs",     "#ff7043", "Edible oils, fuel, transport — basic needs impacted"),
        ],
        "market_sectors": ["Energy", "Defense & Aerospace", "Shipping & Logistics", "FMCG", "Agri"],
        "rss": [
            "https://feeds.reuters.com/reuters/businessNews",
            "https://feeds.reuters.com/reuters/worldNews",
            "https://timesofindia.indiatimes.com/rssfeeds/296589292.cms",
        ],
        "india_impact": (
            "India imports ~87% of its crude oil. Every $10/bbl rise in Brent adds ~₹1.2L cr "
            "to the import bill, weakens INR ~50–80 paise, and pushes petrol/diesel up ₹2–4/litre. "
            "FMCG and logistics companies see direct margin compression."
        ),
        "watchlist": ["BPCL.NS", "IOC.NS", "ONGC.NS", "HAL.NS", "BEL.NS", "MAZDOCK.NS"],
        "attribution": (
            "Figures sourced from Reuters, Al Jazeera, and US EIA reports (2024–2025). "
            "Oil price sensitivity estimates: PPAC India. "
            "Freight cost data: Drewry World Container Index. "
            "Content reviewed periodically; not updated in real time."
        ),
    },
    "🤖 AI & Job Markets": {
        "color": "#4f8ef7",
        "subtitle": "Technology Disruption · Workforce Evolution · New Opportunities",
        "overview": (
            "Generative AI is compressing the automation curve from decades to years. "
            "White-collar roles in software, legal, finance, and media are being repriced. "
            "Simultaneously, new roles in AI oversight, prompt engineering, and human-AI "
            "collaboration are emerging faster than universities can respond."
        ),
        "chain": [
            ("Foundation Model Capabilities", "#0d47a1", "GPT-5, Gemini 2, Claude 4 — reasoning at expert level"),
            ("Enterprise Adoption Wave",      "#1565c0", "70% of Fortune 500 deploying AI co-pilots by 2026"),
            ("Task-Level Automation",         "#1976d2", "Code generation, legal review, customer support, data analysis"),
            ("Job Role Displacement",         "#1e88e5", "Entry-level IT, BPO, content, paralegal at risk"),
            ("Reskilling & New Roles",        "#2196f3", "AI trainers, ethics auditors, integration architects"),
            ("Productivity & GDP Gains",      "#42a5f5", "McKinsey: $4.4T annual value from GenAI"),
            ("Market Repricing",              "#64b5f6", "IT multiples shift — services vs platforms diverge"),
        ],
        "market_sectors": ["IT Services", "Cloud & SaaS", "EdTech", "Robotics", "Semiconductors"],
        "rss": [
            # v5.31: Replaced stale TechCrunch feeds (last active Dec 2025)
            # MIT Tech Review and The Verge AI are current and finance-relevant
            "https://www.artificialintelligence-news.com/feed/",
            "https://feeds.feedburner.com/theinternetpatrol",
        ],
        "india_impact": (
            "India's $250B IT services sector — employing 5.4M people — faces structural repricing. "
            "TCS, Infosys, Wipro are pivoting from headcount-led to AI-led delivery. "
            "Near-term: margin expansion. Medium-term: 20–30% headcount reduction risk in "
            "legacy service lines. New hires skewed toward AI/ML by 3:1 ratio."
        ),
        "watchlist": ["TCS.NS", "INFY.NS", "WIPRO.NS", "HCLTECH.NS", "PERSISTENT.NS", "LTIM.NS"],
    },
    "📉 US Rate Cycle & Fed Policy": {
        "color": "#ffd600",
        "subtitle": "Central Bank Policy · Bond Markets · Dollar Strength · Global Liquidity",
        "overview": (
            "The Federal Reserve's rate cycle is the single most consequential macro variable for "
            "global markets. Rate decisions ripple instantly into equity valuations, currency pairs, "
            "and emerging market capital flows. India, as a high-growth EM, is acutely sensitive "
            "to US rate direction — both through the dollar-rupee channel and FII allocation shifts."
        ),
        "chain": [
            ("Fed Rate Decision",        "#f57f17", "FOMC meets 8x/year — each decision reprices global assets"),
            ("US Bond Yields",           "#f9a825", "10Y Treasury yield anchors equity discount rates globally"),
            ("Dollar Index (DXY)",       "#fbc02d", "Strong USD = capital outflow from EMs including India"),
            ("FII Flows to India",       "#fdd835", "Dollar strength triggers FII selling — Nifty 50 correlation ~0.7"),
            ("INR Depreciation Risk",    "#ffee58", "Weaker rupee inflates import bill, fuel, and tech input costs"),
            ("RBI Policy Response",      "#fff176", "RBI forced to hold rates higher for longer to defend INR"),
            ("India Growth Premium",     "#fff9c4", "Rate spread vs US narrows — growth stocks repriced lower"),
        ],
        "market_sectors": ["Banking & NBFC", "IT Services", "Real Estate", "Auto", "FMCG"],
        "rss": [
            "https://feeds.reuters.com/reuters/businessNews",
            "https://economictimes.indiatimes.com/markets/rssfeeds/1977021501.cms",
        ],
        "india_impact": (
            "Every 25bps Fed hike historically triggers ₹1–2 INR depreciation vs USD. "
            "FII outflows from Indian equity can exceed $3B in a single quarter during rate shock events. "
            "Banking stocks (rate-sensitive) and IT exporters (USD revenue beneficiaries) "
            "move in opposite directions during rate pivots."
        ),
        "watchlist": ["HDFCBANK.NS", "ICICIBANK.NS", "INFY.NS", "TCS.NS", "SBIN.NS", "LT.NS"],
    },
    "🇨🇳 China Slowdown & Trade Shifts": {
        "color": "#ef5350",
        "subtitle": "Export Deflation · Property Crisis · Supply Chain Realignment · India Opportunity",
        "overview": (
            "China's economic model — built on export-led growth and property investment — "
            "is undergoing structural stress. The Evergrande collapse, youth unemployment above 20%, "
            "and Western supply chain diversification are reshaping global trade flows. "
            "India stands as both a beneficiary (manufacturing shift) and a risk recipient "
            "(commodity demand drop, export competition)."
        ),
        "chain": [
            ("Property Sector Collapse", "#b71c1c", "Evergrande + Country Garden — ¥40T debt overhang, demand destruction"),
            ("Domestic Demand Weakness", "#c62828", "Consumer confidence at decade lows, deflation risk"),
            ("Export Dumping Pressure",  "#d32f2f", "Cheap Chinese goods flood Asian markets, hurting local industry"),
            ("Supply Chain Shift",       "#e53935", "Apple, Samsung, Dell diversifying to India, Vietnam, Mexico"),
            ("Commodity Demand Drop",    "#ef5350", "Iron ore, copper, soy demand falls — commodity exporters impacted"),
            ("India Manufacturing Gain", "#ff5252", "PLI scheme + China+1 — electronics, pharma, autos shifting in"),
            ("Geopolitical Decoupling",  "#ff8a80", "US-China tech war creates permanent structural realignment"),
        ],
        "market_sectors": ["Metals & Mining", "Chemicals", "Electronics Mfg", "Pharma", "Textiles"],
        "rss": [
            "https://feeds.reuters.com/reuters/worldNews",
            "https://economictimes.indiatimes.com/markets/rssfeeds/1977021501.cms",
        ],
        "india_impact": (
            "India's PLI scheme targets $300B in manufacturing output by 2030, directly tied to China+1. "
            "Risks: Chinese steel dumping hits Tata Steel and JSW margins. "
            "Opportunity: Dixon Technologies, Kaynes Technology, and Tata Electronics "
            "are direct beneficiaries of electronics supply chain shift."
        ),
        "watchlist": ["TATASTEEL.NS", "JSWSTEEL.NS", "DIXON.NS", "TATAELXSI.NS", "SUNPHARMA.NS", "CIPLA.NS"],
    },
    "🌾 Commodities & Global Inflation": {
        "color": "#66bb6a",
        "subtitle": "Oil · Gold · Agriculture · Supply Shocks · Inflation Transmission",
        "overview": (
            "Commodity markets are the inflation transmission layer for the global economy. "
            "Crude oil reprices every supply chain. Gold signals real-rate expectations. "
            "Agriculture shocks (drought, conflict, export bans) create food inflation "
            "that affects consumer spending power — particularly in India where food "
            "constitutes nearly 40% of the CPI basket."
        ),
        "chain": [
            ("Crude Oil Price (Brent)",   "#1b5e20", "OPEC+ cuts + geopolitical risk premium drive Brent"),
            ("Natural Gas & LNG",         "#2e7d32", "Energy transition + Russia supply disruption raises prices"),
            ("Gold (Real Rates Signal)",  "#388e3c", "Inverse to real yields — Fed pivot expectations drive gold"),
            ("Agriculture Price Shocks",  "#43a047", "El Niño + Ukraine war disrupts wheat, corn, palm oil"),
            ("Input Cost Surge",          "#4caf50", "Fertiliser, packaging, transport costs compress margins"),
            ("CPI & Core Inflation",      "#66bb6a", "Food + energy = 55% of India CPI — RBI policy trigger"),
            ("RBI Rate Response",         "#81c784", "Persistent inflation above 6% forces RBI hawkish pivot"),
        ],
        "market_sectors": ["Energy", "FMCG", "Agriculture", "Fertilisers", "Metals"],
        "rss": [
            "https://feeds.reuters.com/reuters/businessNews",
            "https://timesofindia.indiatimes.com/rssfeeds/296589292.cms",
        ],
        "india_impact": (
            "India imports ~87% of crude oil — Brent above $90/bbl pushes fuel subsidies "
            "and widens the Current Account Deficit. Agricultural stocks (UPL, Coromandel) "
            "benefit from high crop prices. FMCG companies (HUL, Nestle) face gross margin "
            "compression when palm oil and wheat prices spike."
        ),
        "watchlist": ["ONGC.NS", "BPCL.NS", "HINDUNILVR.NS", "ITC.NS", "COROMANDEL.NS", "UPL.NS"],
    },
}

NEXT_STEPS_AI: list = [
    ("📚 Upskill Immediately",
     "Python + LLM APIs (OpenAI, Gemini). 3 months of consistent learning creates a "
     "defensible skill moat. Free resources: fast.ai, Deeplearning.ai, Hugging Face.", "#00c853"),
    ("💼 Audit Your Role",
     "Identify which 40% of your daily tasks could be AI-assisted. Build that tool yourself — "
     "it makes you the expert instead of the disrupted.", "#4f8ef7"),
    ("📈 Invest in the Infrastructure",
     "AI demand runs on semiconductors (NVDA, TSM), cloud (MSFT Azure, AWS, GCP), and "
     "data pipelines. Platform winners compound faster than service providers.", "#ff9800"),
    ("🌐 Follow the Hiring Signal",
     "Track job postings weekly for AI roles in your sector. A 3x spike in a domain is a "
     "leading indicator of where value is migrating — both as a career and investment signal.", "#e040fb"),
    ("🛡️ Diversify Income Streams",
     "AI makes knowledge productisable. Build one passive asset: a course, a tool, a niche "
     "newsletter. These compound while your primary income remains intact.", "#00bcd4"),
]

# ── KPI help tooltips ─────────────────────────────────────────────────────────
KPI_HELP: dict = {
    "Price":      "Latest closing price from Yahoo Finance",
    "Change %":   "1-day percentage change vs prior close",
    "52W High":   "Highest price over the trailing 52 weeks",
    "52W Low":    "Lowest price over the trailing 52 weeks",
    "Volume":     "Total shares/units traded today",
    "Market Cap": "Total market capitalisation",
    "P/E Ratio":  "Price-to-Earnings — valuation multiple",
    "Beta":       "Volatility relative to the broader market (1 = market, >1 = more volatile)",
}

# ── Technical & section help text ────────────────────────────────────────────
HELP_TEXT: dict = {
    # ── Header badges ─────────────────────────────────────────────
    "signal": (
        "The unified verdict — derived from three layers: "
        "(1) Weinstein Stage cycle, (2) Elder weekly tide, (3) momentum score. "
        "STRONG BUY = all layers aligned bullish. BUY = good setup with minor caveats. "
        "WATCH = mixed signals or unconfirmed trend — monitor, do not act yet. "
        "AVOID = confirmed downtrend overrides all bullish signals. "
        "This is the only signal you should act on. See Insights tab for full rationale."
    ),
    "score": (
        "Momentum Score (0–100) — measures short-term technical alignment only. "
        "Combines RSI, MACD, SMA trend, Bollinger position, volume, and ADX. "
        "This score is one input — not the final verdict. "
        "The verdict badge (shown above) applies additional filters: "
        "Weinstein Stage cycle and Elder weekly tide. "
        "A high score with a weak trend cycle will be downgraded to WATCH or AVOID. "
        "A high score with a confirmed uptrend will show as BUY or STRONG BUY. "
        "Above 60 = strong momentum. Below 40 = weak. 40–60 = neutral."
    ),
    "ticker": (
        "Exchange symbol used to fetch live data. "
        ".NS = NSE India. .BO = Bombay Stock Exchange. No suffix = US (NYSE/Nasdaq). "
        "^ prefix = market index (e.g. ^NSEI = Nifty 50, ^GSPC = S&P 500). "
        "=F suffix = futures contract (e.g. GC=F = Gold futures). "
        "Debt & Rates values are yields (%); Global Indices values are in points (Pts)."
    ),
    # ── Verdict & regime (v5.19) ──────────────────────────────────
    "unified_verdict": (
        "The final verdict applies three filters in order: "
        "(1) Weinstein Stage — if Stage 4 (declining), verdict = AVOID regardless of score. "
        "(2) Elder weekly tide — if weekly MACD histogram falling, BUY signals are suppressed. "
        "(3) Momentum score — only used if Stage and tide are supportive. "
        "This layered approach prevents bullish momentum signals in declining trends "
        "from misleading you into 'catching a falling knife'."
    ),
    "weinstein_stage": (
        "Weinstein Stage Analysis (Stan Weinstein, 'Secrets for Profiting in Bull and Bear Markets'). "
        "Classifies stock cycle using the 30-week (150-day) moving average: "
        "Stage 1 = Base/Accumulation (price near flat MA — wait for breakout). "
        "Stage 2 = Advancing (price above rising MA — BUY signals valid). "
        "Stage 3 = Top/Distribution (price stalling near MA — caution). "
        "Stage 4 = Declining (price below falling MA — AVOID, no buy signal is reliable). "
        "Stage 4 is a hard override — it suppresses all BUY signals regardless of momentum score."
    ),
    "elder_screen": (
        "Elder Triple Screen (Alexander Elder, 'Trading for a Living'). "
        "The weekly MACD histogram direction is the 'tide' — the master trend filter. "
        "A RISING weekly histogram = bullish tide (daily buy signals valid). "
        "A FALLING weekly histogram = bearish tide (daily buy signals suppressed). "
        "The key insight: the weekly tide must agree with the daily signal. "
        "Buying against a bearish weekly tide is low-probability even when daily indicators look bullish."
    ),
    "p_gain": (
        "P(Gain) = probability the price is higher at the end of the forecast horizon than today. "
        "Derived from 2,000 bootstrapped historical return paths. "
        "Above 55% = leans bullish. 45–55% = roughly balanced. Below 45% = leans bearish. "
        "Limitation: based on past return distribution only — does not know about upcoming "
        "earnings, macro events, or fundamental changes. Use as one input, not the only one."
    ),
    "hist_sim": (
        "Historical Simulation forecast: 2,000 price paths generated by randomly drawing "
        "from this stock's actual daily log-returns (bootstrap method). "
        "Unlike standard Monte Carlo (which assumes normal distribution), this method "
        "preserves the stock's real fat tails — extreme moves are captured as they actually "
        "occurred historically. The fan shows P10/P25/P50/P75/P90 outcome percentiles. "
        "Max horizon 63 days — beyond this, volatility dominates direction and forecasts "
        "become statistically unreliable."
    ),
    "conflict": (
        "A signal conflict occurs when the momentum score suggests BUY but the regime "
        "filters (Weinstein Stage or Elder tide) override it to WATCH or AVOID. "
        "The most common case: RSI is oversold (strong buy signal) but the stock is in "
        "a Stage 4 downtrend — this is called 'catching a falling knife'. "
        "RSI goes oversold repeatedly on the way down, firing false buy signals each time. "
        "The regime filter prevents acting on these. When a conflict is shown, "
        "the verdict (not the score) is what you should act on."
    ),
    # ── KPI panel ─────────────────────────────────────────────────
    "rsi": (
        "RSI (Relative Strength Index, 14 days) — momentum on a 0–100 scale. "
        "Below 30 = oversold, potential bounce. Above 70 = overbought, potential pullback. "
        "30–70 = neutral zone. Note: oversold in a downtrend is not a buy signal — "
        "check the verdict badge first."
    ),
    "macd_h": (
        "MACD Histogram = MACD line minus Signal line. "
        "Positive and growing = buying momentum building. "
        "Negative and shrinking = selling pressure easing. "
        "Flip from negative → positive = early buy signal."
    ),
    "bbw": (
        "Bollinger Band Width — how wide the price bands are vs the moving average (%). "
        "High % = high volatility, large swings expected. "
        "Low % = quiet market, often precedes a sharp breakout."
    ),
    "atr": (
        "ATR (Average True Range) — average daily price swing in currency terms. "
        "Higher = more volatile. Use to size positions: larger ATR = smaller position size."
    ),
    "adx": (
        "ADX (Average Directional Index) — trend strength, not direction. "
        "Above 25 = strong trend in place. Below 20 = no clear trend, ranging market."
    ),
    "stoch": (
        "Stochastic %K — today's price vs recent highs/lows (0–100). "
        "Below 30 = near recent low, potential buy zone. "
        "Above 75 = near recent high, potential sell zone."
    ),
    "pe_pb": (
        "P/E (Price-to-Earnings): how much you pay per unit of profit. "
        "P/B (Price-to-Book): how much you pay vs net asset value. "
        "Lower values = potentially cheaper — but fast-growing companies carry higher ratios. "
        "Not applicable to commodities, futures, or market indices."
    ),
    "roe_revg": (
        "ROE (Return on Equity): how efficiently the company uses shareholder money — above 15% is strong. "
        "Rev Growth: year-on-year revenue growth %. Positive = business expanding. "
        "Not applicable to commodities, futures, or market indices."
    ),
    "obv_vol": (
        "OBV (On-Balance Volume): running total of buying vs selling pressure (millions). "
        "Rising OBV with rising price = healthy uptrend. "
        "Falling OBV with rising price = rally may be running out of steam."
    ),
    # ── Charts tab ────────────────────────────────────────────────
    "sma": (
        "SMA (Simple Moving Average) — average closing price over a period. "
        "SMA20 (cyan) = short-term. SMA50 (yellow) = medium. SMA200 (orange) = long-term. "
        "Price above all three = strong uptrend (Weinstein Stage 2 territory)."
    ),
    "bollinger": (
        "Bollinger Bands — 2 standard deviations above/below SMA20. "
        "Price at upper band = potentially overbought. Price at lower band = potentially oversold. "
        "Bands squeezing = low volatility, breakout often follows."
    ),
    "candlestick": (
        "Each candle = one trading day. "
        "Green = closed higher than it opened (bullish). Red = closed lower (bearish). "
        "Thin wicks = the day's high and low range."
    ),
    # ── Forecast tab ─────────────────────────────────────────────
    "lookback": (
        "Days of historical data used to calculate the trend direction. "
        "Longer = smoother long-term signal. Shorter = more responsive to recent moves."
    ),
    "horizon": (
        "How far ahead the forecast projects. 1M = 21 trading days. 3M = 63 days. "
        "Forecast reliability decreases sharply beyond 63 days — volatility dominates. "
        "6M and 12M forecasts are not offered as they are statistically unreliable."
    ),
    "confidence_band": (
        "Probability fan from 2,000 bootstrapped historical paths. "
        "Inner band (darker) = central 50% of outcomes (P25–P75). "
        "Outer band (lighter) = 80% of outcomes (P10–P90). "
        "20% of paths will fall outside the outer band — extreme moves are always possible."
    ),
    # ── Insights tab ─────────────────────────────────────────────
    "insights_section": (
        "Plain-English summary of what the signals are saying — "
        "momentum, trend cycle, and forecast combined into one view."
    ),
    "actions_section": (
        "Suggested starting points based on the unified verdict. "
        "Not financial advice — always consider your own risk tolerance and timeline."
    ),
    "cautions_section": (
        "Warning flags from the analysis. "
        "Even BUY-rated stocks can have cautions — use these to manage risk."
    ),
    # ── Home page ─────────────────────────────────────────────────
    "market_status": (
        "Live session status based on official trading hours. "
        "OPEN = you can trade now. CLOSED = prices shown are from the last close. "
        "Times shown in the exchange's local timezone."
    ),
    "top_movers": (
        "Stocks with the highest % price change today. "
        "High movers often have news or events driving them — click a name to investigate."
    ),
    # ── Week summary ──────────────────────────────────────────────
    "weekly_heatmap": (
        "Weekly return for each Nifty 50 stock (% change from Monday open to now). "
        "Green = positive week. Red = negative week. Longer bar = bigger move."
    ),
    "sector_snapshot": (
        "Weekly performance of each major NSE sector index. "
        "Shows which sectors are leading (outperforming) vs lagging this week."
    ),
}